from pathlib import Path
from textwrap import dedent

ROOT = Path.cwd()


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(dedent(content).lstrip(), encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one replacement, found {count}: {old[:160]!r}")
    target.write_text(text.replace(old, new), encoding="utf-8")


def append_once(path: str, marker: str, content: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    if marker in text:
        return
    target.write_text(text.rstrip() + "\n\n" + dedent(content).strip() + "\n", encoding="utf-8")


write("infra/d1/core/migrations/0093_computer_agent_dispatch_reassignment.sql", r'''
-- Explicit owner reassignment from one terminal, unaccepted dispatch to one fresh dispatch.
-- The frozen Research request is reused by digest; actor, grant, qualification, dispatch and lease identities are never transferred.
PRAGMA foreign_keys = ON;

CREATE TABLE computer_agent_dispatch_reassignment (
  predecessor_dispatch_id TEXT PRIMARY KEY REFERENCES computer_agent_dispatch(dispatch_id),
  successor_dispatch_id TEXT NOT NULL UNIQUE REFERENCES computer_agent_dispatch(dispatch_id),
  project_id TEXT NOT NULL CHECK(length(project_id) BETWEEN 1 AND 256),
  owner_principal_ref TEXT NOT NULL CHECK(length(owner_principal_ref) BETWEEN 1 AND 256),
  owner_credential_generation TEXT NOT NULL CHECK(length(owner_credential_generation) BETWEEN 1 AND 256),
  predecessor_state TEXT NOT NULL CHECK(predecessor_state IN ('ABANDONED','DECLINED')),
  run_request_sha256 TEXT NOT NULL
    CHECK(length(run_request_sha256)=64 AND run_request_sha256 NOT GLOB '*[^0-9a-f]*'),
  successor_transport TEXT NOT NULL CHECK(successor_transport IN ('MCP_WRITE','WEB_INBOX')),
  successor_route_revision INTEGER NOT NULL CHECK(successor_route_revision BETWEEN 1 AND 2147483647),
  successor_connection_id TEXT NOT NULL CHECK(length(successor_connection_id) BETWEEN 1 AND 256),
  successor_connection_revision INTEGER NOT NULL CHECK(successor_connection_revision BETWEEN 1 AND 2147483647),
  successor_client_grant_id TEXT NOT NULL CHECK(length(successor_client_grant_id) BETWEEN 1 AND 256),
  successor_client_grant_revision INTEGER NOT NULL CHECK(successor_client_grant_revision BETWEEN 1 AND 2147483647),
  idempotency_key TEXT NOT NULL CHECK(length(idempotency_key) BETWEEN 1 AND 256),
  request_sha256 TEXT NOT NULL
    CHECK(length(request_sha256)=64 AND request_sha256 NOT GLOB '*[^0-9a-f]*'),
  record_json TEXT NOT NULL
    CHECK(json_valid(record_json) AND length(CAST(record_json AS BLOB)) BETWEEN 1 AND 49152),
  record_sha256 TEXT NOT NULL
    CHECK(length(record_sha256)=64 AND record_sha256 NOT GLOB '*[^0-9a-f]*'),
  reassigned_at TEXT NOT NULL CHECK(julianday(reassigned_at) IS NOT NULL),
  UNIQUE(owner_principal_ref,idempotency_key),
  CHECK(predecessor_dispatch_id<>successor_dispatch_id),
  CHECK(json_extract(record_json,'$.protocol') IS 'eliotr.computer-agent-dispatch-reassigned.v1'),
  CHECK(json_extract(record_json,'$.predecessor_dispatch_id') IS predecessor_dispatch_id),
  CHECK(json_extract(record_json,'$.successor_dispatch_id') IS successor_dispatch_id),
  CHECK(json_extract(record_json,'$.project_id') IS project_id),
  CHECK(json_extract(record_json,'$.owner_principal_ref') IS owner_principal_ref),
  CHECK(json_extract(record_json,'$.owner_credential_generation') IS owner_credential_generation),
  CHECK(json_extract(record_json,'$.predecessor_state') IS predecessor_state),
  CHECK(json_extract(record_json,'$.run_request_sha256') IS run_request_sha256),
  CHECK(json_extract(record_json,'$.successor_transport') IS successor_transport),
  CHECK(json_extract(record_json,'$.successor_route_revision') IS successor_route_revision),
  CHECK(json_extract(record_json,'$.successor_connection_id') IS successor_connection_id),
  CHECK(json_extract(record_json,'$.successor_connection_revision') IS successor_connection_revision),
  CHECK(json_extract(record_json,'$.successor_client_grant_id') IS successor_client_grant_id),
  CHECK(json_extract(record_json,'$.successor_client_grant_revision') IS successor_client_grant_revision),
  CHECK(json_extract(record_json,'$.idempotency_key') IS idempotency_key),
  CHECK(json_extract(record_json,'$.request_sha256') IS request_sha256),
  CHECK(json_extract(record_json,'$.reassigned_at') IS reassigned_at)
) STRICT;

CREATE INDEX computer_agent_dispatch_reassignment_owner_idx
  ON computer_agent_dispatch_reassignment(
    owner_principal_ref,reassigned_at DESC,predecessor_dispatch_id DESC
  );

CREATE TRIGGER computer_agent_dispatch_reassignment_insert_guard
BEFORE INSERT ON computer_agent_dispatch_reassignment
WHEN NOT EXISTS (
  SELECT 1
  FROM computer_agent_dispatch p
  JOIN computer_agent_dispatch s ON s.dispatch_id=NEW.successor_dispatch_id
  JOIN project_owner o ON o.project_id=p.project_id AND o.principal_ref=p.owner_principal_ref
  LEFT JOIN computer_agent_dispatch_acceptance pa ON pa.dispatch_id=p.dispatch_id
  LEFT JOIN computer_agent_dispatch_abandonment px ON px.dispatch_id=p.dispatch_id
  LEFT JOIN computer_agent_dispatch_decline pd ON pd.dispatch_id=p.dispatch_id
  LEFT JOIN computer_agent_dispatch_acceptance sa ON sa.dispatch_id=s.dispatch_id
  LEFT JOIN computer_agent_dispatch_abandonment sx ON sx.dispatch_id=s.dispatch_id
  LEFT JOIN computer_agent_dispatch_decline sd ON sd.dispatch_id=s.dispatch_id
  WHERE p.dispatch_id=NEW.predecessor_dispatch_id
    AND p.project_id=NEW.project_id AND s.project_id=NEW.project_id
    AND p.owner_principal_ref=NEW.owner_principal_ref
    AND s.owner_principal_ref=NEW.owner_principal_ref
    AND s.owner_credential_generation=NEW.owner_credential_generation
    AND p.run_request_sha256=NEW.run_request_sha256
    AND s.run_request_sha256=NEW.run_request_sha256
    AND s.transport=NEW.successor_transport
    AND s.route_revision=NEW.successor_route_revision
    AND s.connection_id=NEW.successor_connection_id
    AND s.connection_revision=NEW.successor_connection_revision
    AND s.client_grant_id=NEW.successor_client_grant_id
    AND s.client_grant_revision=NEW.successor_client_grant_revision
    AND pa.dispatch_id IS NULL
    AND sa.dispatch_id IS NULL AND sx.dispatch_id IS NULL AND sd.dispatch_id IS NULL
    AND (
      (NEW.predecessor_state='ABANDONED' AND px.dispatch_id IS NOT NULL AND pd.dispatch_id IS NULL
        AND julianday(NEW.reassigned_at)>=julianday(px.abandoned_at))
      OR
      (NEW.predecessor_state='DECLINED' AND pd.dispatch_id IS NOT NULL AND px.dispatch_id IS NULL
        AND julianday(NEW.reassigned_at)>=julianday(pd.declined_at))
    )
    AND julianday(s.created_at)>=julianday(p.created_at)
    AND julianday(NEW.reassigned_at)>=julianday(s.created_at)
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_REASSIGNMENT_INVALID'); END;

CREATE TRIGGER computer_agent_dispatch_reassignment_no_update
BEFORE UPDATE ON computer_agent_dispatch_reassignment
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_REASSIGNMENT_IMMUTABLE'); END;
CREATE TRIGGER computer_agent_dispatch_reassignment_no_delete
BEFORE DELETE ON computer_agent_dispatch_reassignment
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_REASSIGNMENT_IMMUTABLE'); END;

INSERT INTO schema_state(key,value,updated_at)
VALUES('computer_agent_dispatch_reassignment_generation',
  'computer-agent-dispatch-reassignment-v1',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
''')

write("apps/eliotr-core/src/computer-agent-dispatch-reassignment.ts", r'''
import {
  ComputerAgentDispatchReassignSchema,
  ComputerAgentDispatchReassignmentSchema,
  type ComputerAgentDispatchCreate,
  type ComputerAgentDispatchReassignment,
} from "@eliotr/contracts";
import type { AuthenticatedRequestContext } from "@eliotr/interfaces";
import { canonicalJson, sha256Utf8 } from "@eliotr/platform-cloudflare";
import {
  decodeComputerAgentDispatch,
  decodeComputerAgentDispatchReassignment,
  readComputerAgentDispatchReassignmentReplay,
  readComputerAgentDispatchReassignmentRow,
  readComputerAgentDispatchRow,
} from "./computer-agent-dispatch-record.js";
import { failComputerAgentDispatch as fail } from "./computer-agent-dispatch-error.js";
import { readComputerAgentDispatchStatus } from "./computer-agent-dispatch-status.js";
import { createComputerAgentDispatchService } from "./computer-agent-dispatch-store.js";
import type { Env } from "./env.js";

const SCHEMA_GENERATION = "computer-agent-dispatch-reassignment-v1";
const ID = /^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,255}$/u;
const KEY = /^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$/u;

function identifier(value: unknown, label: string): string {
  if (typeof value !== "string" || !ID.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400, `${label} is invalid`);
  }
  return value;
}
function idempotency(value: unknown): string {
  if (typeof value !== "string" || !KEY.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
      "Idempotency-Key is required and invalid");
  }
  return value;
}
function instant(now: () => number): number {
  let value: number;
  try { value = now(); }
  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
    "Dispatch reassignment clock is unavailable", true); }
  if (!Number.isSafeInteger(value) || value < 0) {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Dispatch reassignment clock is invalid", true);
  }
  return value;
}
function owner(context: AuthenticatedRequestContext, now: () => number) {
  const current = instant(now);
  if (context.client_class !== "owner_pwa" || context.request.signal.aborted) {
    fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
      "A current owner request is required");
  }
  if (context.access && (context.access.principal_ref !== context.principal_ref ||
      context.access.credential_generation !== context.credential_generation ||
      !Number.isFinite(Date.parse(context.access.expires_at)) ||
      Date.parse(context.access.expires_at) <= current)) {
    fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
      "Owner session is no longer current");
  }
  return Object.freeze({
    principal_ref: identifier(context.principal_ref, "owner principal"),
    credential_generation: identifier(context.credential_generation,
      "owner credential generation"),
  });
}
async function requireSchema(db: D1Database): Promise<void> {
  let value: string | null;
  try {
    value = await db.prepare(
      "SELECT value FROM schema_state " +
      "WHERE key='computer_agent_dispatch_reassignment_generation'",
    ).first<string>("value");
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch reassignment migration 0093 is required", true);
  }
  if (value !== SCHEMA_GENERATION) {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch reassignment migration 0093 is required", true);
  }
}
function derivedContext(
  context: AuthenticatedRequestContext,
  successorKey: string,
): AuthenticatedRequestContext {
  const headers = new Headers(context.request.headers);
  headers.set("Idempotency-Key", successorKey);
  return Object.freeze({
    ...context,
    request: new Request(context.request.url, {
      method: "POST",
      headers,
      signal: context.request.signal,
    }),
  });
}

export function createComputerAgentDispatchReassignmentService(
  env: Env,
  options?: { readonly now?: () => number },
) {
  const db = env.CORE_DB;
  const now = options?.now ?? Date.now;

  async function reassign(
    context: AuthenticatedRequestContext,
    projectIdValue: string,
    predecessorIdValue: string,
    rawInput: unknown,
  ): Promise<ComputerAgentDispatchReassignment> {
    await requireSchema(db);
    const identity = owner(context, now);
    const projectId = identifier(projectIdValue, "project_id");
    const predecessorId = identifier(predecessorIdValue, "predecessor dispatch_id");
    const parsed = ComputerAgentDispatchReassignSchema.safeParse(rawInput);
    if (!parsed.success) {
      fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
        "Dispatch reassignment contains unknown or invalid fields");
    }
    const key = idempotency(context.request.headers.get("Idempotency-Key"));
    const predecessorRow = await readComputerAgentDispatchRow(db, predecessorId);
    if (predecessorRow === null) {
      fail("COMPUTER_AGENT_DISPATCH_NOT_FOUND", 404,
        "Predecessor dispatch does not exist");
    }
    const predecessor = await decodeComputerAgentDispatch(predecessorRow);
    if (predecessor.project_id !== projectId ||
        predecessor.owner_principal_ref !== identity.principal_ref) {
      fail("COMPUTER_AGENT_DISPATCH_NOT_FOUND", 404,
        "Predecessor dispatch does not exist in this owner project");
    }
    const current = instant(now);
    const status = await readComputerAgentDispatchStatus({
      database: db,
      dispatch: predecessor,
      now: current,
    });
    if (status.state !== "ABANDONED" && status.state !== "DECLINED") {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Only an abandoned or declined predecessor may be reassigned");
    }
    if (status.state !== parsed.data.expected_predecessor_state) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Predecessor terminal state changed before reassignment");
    }
    if (parsed.data.expected_run_request_sha256 !== predecessor.run_request_sha256) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Frozen Research request changed before reassignment");
    }
    const requestSha = await sha256Utf8(canonicalJson({
      protocol: "eliotr.computer-agent-dispatch-reassignment-request.v1",
      predecessor_dispatch_id: predecessor.dispatch_id,
      project_id: projectId,
      owner_principal_ref: identity.principal_ref,
      idempotency_key: key,
      input: parsed.data,
    }));
    const [byPredecessor, replay] = await Promise.all([
      readComputerAgentDispatchReassignmentRow(db, predecessor.dispatch_id),
      readComputerAgentDispatchReassignmentReplay(db, identity.principal_ref, key),
    ]);
    const existing = byPredecessor ?? replay;
    if (existing !== null) {
      if (existing.predecessor_dispatch_id !== predecessor.dispatch_id ||
          existing.request_sha256 !== requestSha ||
          existing.idempotency_key !== key) {
        fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
          "Dispatch or Idempotency-Key is already bound to another reassignment");
      }
      owner(context, now);
      return decodeComputerAgentDispatchReassignment(existing);
    }

    const successorKeyDigest = await sha256Utf8(canonicalJson({
      protocol: "eliotr.computer-agent-dispatch-reassignment-successor-key.v1",
      predecessor_dispatch_id: predecessor.dispatch_id,
      owner_principal_ref: identity.principal_ref,
      reassignment_idempotency_key: key,
      reassignment_request_sha256: requestSha,
    }));
    const successorInput: ComputerAgentDispatchCreate = {
      transport: parsed.data.transport,
      expected_route_revision: parsed.data.expected_route_revision,
      connection_id: parsed.data.connection_id,
      connection_revision: parsed.data.connection_revision,
      client_grant_id: parsed.data.client_grant_id,
      client_grant_revision: parsed.data.client_grant_revision,
      expires_in_seconds: parsed.data.expires_in_seconds,
      run_request: predecessor.run_request,
    };
    const successor = await createComputerAgentDispatchService(env, { now }).create(
      derivedContext(context, `computer-agent-reassign:${successorKeyDigest}`),
      projectId,
      successorInput,
    );
    if (successor.dispatch_id === predecessor.dispatch_id ||
        successor.project_id !== predecessor.project_id ||
        successor.owner_principal_ref !== identity.principal_ref ||
        successor.run_request_sha256 !== predecessor.run_request_sha256 ||
        successor.transport !== parsed.data.transport ||
        successor.route_revision !== parsed.data.expected_route_revision ||
        successor.connection_id !== parsed.data.connection_id ||
        successor.connection_revision !== parsed.data.connection_revision ||
        successor.client_grant_id !== parsed.data.client_grant_id ||
        successor.client_grant_revision !== parsed.data.client_grant_revision) {
      fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
        "Successor dispatch readback differs from the reassignment request");
    }
    const reassignedAt = new Date(instant(now)).toISOString();
    const receipt = ComputerAgentDispatchReassignmentSchema.parse({
      protocol: "eliotr.computer-agent-dispatch-reassigned.v1",
      predecessor_dispatch_id: predecessor.dispatch_id,
      successor_dispatch_id: successor.dispatch_id,
      project_id: projectId,
      owner_principal_ref: identity.principal_ref,
      owner_credential_generation: identity.credential_generation,
      predecessor_state: status.state,
      run_request_sha256: predecessor.run_request_sha256,
      successor_transport: successor.transport,
      successor_route_revision: successor.route_revision,
      successor_connection_id: successor.connection_id,
      successor_connection_revision: successor.connection_revision,
      successor_client_grant_id: successor.client_grant_id,
      successor_client_grant_revision: successor.client_grant_revision,
      idempotency_key: key,
      request_sha256: requestSha,
      reassigned_at: reassignedAt,
    });
    const record = canonicalJson(receipt);
    const recordSha = await sha256Utf8(record);
    owner(context, now);
    let mutationError: unknown;
    try {
      await db.prepare("INSERT INTO computer_agent_dispatch_reassignment(" +
        "predecessor_dispatch_id,successor_dispatch_id,project_id,owner_principal_ref," +
        "owner_credential_generation,predecessor_state,run_request_sha256," +
        "successor_transport,successor_route_revision,successor_connection_id," +
        "successor_connection_revision,successor_client_grant_id," +
        "successor_client_grant_revision,idempotency_key,request_sha256,record_json," +
        "record_sha256,reassigned_at) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9," +
        "?10,?11,?12,?13,?14,?15,?16,?17,?18)")
        .bind(receipt.predecessor_dispatch_id, receipt.successor_dispatch_id,
          receipt.project_id, receipt.owner_principal_ref,
          receipt.owner_credential_generation, receipt.predecessor_state,
          receipt.run_request_sha256, receipt.successor_transport,
          receipt.successor_route_revision, receipt.successor_connection_id,
          receipt.successor_connection_revision, receipt.successor_client_grant_id,
          receipt.successor_client_grant_revision, receipt.idempotency_key,
          receipt.request_sha256, record, recordSha, receipt.reassigned_at).run();
    } catch (error) { mutationError = error; }
    const settled = await readComputerAgentDispatchReassignmentRow(
      db, predecessor.dispatch_id,
    );
    if (settled === null) {
      fail("COMPUTER_AGENT_DISPATCH_SETTLEMENT_UNCERTAIN", 503,
        mutationError === undefined ? "Dispatch reassignment was not recorded" :
          "Dispatch reassignment acknowledgement is uncertain", true);
    }
    const decoded = await decodeComputerAgentDispatchReassignment(settled);
    if (canonicalJson(decoded) !== record) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Recorded reassignment differs from the requested successor");
    }
    owner(context, now);
    return decoded;
  }

  return { reassign };
}
''')

# Status gains a required reassignment field, so advance the generated DTO protocol.
replace_once(
    "packages/contracts/src/computer-agent-dispatch.ts",
    'protocol: z.literal("eliotr.computer-agent-dispatch-status.v1"),',
    'protocol: z.literal("eliotr.computer-agent-dispatch-status.v2"),',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    'protocol: "eliotr.computer-agent-dispatch-status.v1",',
    'protocol: "eliotr.computer-agent-dispatch-status.v2",',
)

# Contract: add reassignment request/receipt immediately before the status enum.
replace_once(
    "packages/contracts/src/computer-agent-dispatch.ts",
    '''export const ComputerAgentDispatchStateSchema = z.enum([\n''',
    '''export const ComputerAgentDispatchReassignSchema = z.object({\n  expected_predecessor_state: z.enum(["ABANDONED", "DECLINED"]),\n  expected_run_request_sha256: Sha256Schema,\n  transport: ComputerAgentQualificationTransportSchema,\n  expected_route_revision: revision,\n  connection_id: id,\n  connection_revision: revision,\n  client_grant_id: id,\n  client_grant_revision: revision,\n  expires_in_seconds: z.number().int().min(60).max(3600),\n}).strict();\nexport type ComputerAgentDispatchReassign =\n  z.infer<typeof ComputerAgentDispatchReassignSchema>;\n\nexport const ComputerAgentDispatchReassignmentSchema = z.object({\n  protocol: z.literal("eliotr.computer-agent-dispatch-reassigned.v1"),\n  predecessor_dispatch_id: id,\n  successor_dispatch_id: id,\n  project_id: id,\n  owner_principal_ref: id,\n  owner_credential_generation: id,\n  predecessor_state: z.enum(["ABANDONED", "DECLINED"]),\n  run_request_sha256: Sha256Schema,\n  successor_transport: ComputerAgentQualificationTransportSchema,\n  successor_route_revision: revision,\n  successor_connection_id: id,\n  successor_connection_revision: revision,\n  successor_client_grant_id: id,\n  successor_client_grant_revision: revision,\n  idempotency_key: actionKey,\n  request_sha256: Sha256Schema,\n  reassigned_at: IsoDateTimeSchema,\n}).strict().superRefine((value, context) => {\n  if (value.predecessor_dispatch_id === value.successor_dispatch_id) {\n    context.addIssue({ code: "custom", path: ["successor_dispatch_id"],\n      message: "Reassignment must create a distinct successor dispatch" });\n  }\n});\nexport type ComputerAgentDispatchReassignment =\n  z.infer<typeof ComputerAgentDispatchReassignmentSchema>;\n\nexport const ComputerAgentDispatchStateSchema = z.enum([\n''',
)
replace_once(
    "packages/contracts/src/computer-agent-dispatch.ts",
    '''  decline: ComputerAgentDispatchDeclineReceiptSchema.nullable(),\n}).strict().superRefine((value, context) => {\n''',
    '''  decline: ComputerAgentDispatchDeclineReceiptSchema.nullable(),\n  reassignment: ComputerAgentDispatchReassignmentSchema.nullable(),\n}).strict().superRefine((value, context) => {\n''',
)
replace_once(
    "packages/contracts/src/computer-agent-dispatch.ts",
    '''  if (value.decline !== null && (\n    value.decline.dispatch_id !== value.dispatch.dispatch_id ||\n    value.decline.project_id !== value.dispatch.project_id ||\n    value.decline.connection_id !== value.dispatch.connection_id ||\n    value.decline.connection_revision !== value.dispatch.connection_revision ||\n    value.decline.actor.issuer !== value.dispatch.actor.issuer ||\n    value.decline.actor.subject !== value.dispatch.actor.subject\n  )) {\n    context.addIssue({ code: "custom", path: ["decline", "dispatch_id"],\n      message: "Decline receipt is bound to another dispatch target" });\n  }\n});\n''',
    '''  if (value.decline !== null && (\n    value.decline.dispatch_id !== value.dispatch.dispatch_id ||\n    value.decline.project_id !== value.dispatch.project_id ||\n    value.decline.connection_id !== value.dispatch.connection_id ||\n    value.decline.connection_revision !== value.dispatch.connection_revision ||\n    value.decline.actor.issuer !== value.dispatch.actor.issuer ||\n    value.decline.actor.subject !== value.dispatch.actor.subject\n  )) {\n    context.addIssue({ code: "custom", path: ["decline", "dispatch_id"],\n      message: "Decline receipt is bound to another dispatch target" });\n  }\n  if (value.reassignment !== null && (\n    (value.state !== "ABANDONED" && value.state !== "DECLINED") ||\n    value.reassignment.predecessor_state !== value.state ||\n    value.reassignment.predecessor_dispatch_id !== value.dispatch.dispatch_id ||\n    value.reassignment.project_id !== value.dispatch.project_id ||\n    value.reassignment.owner_principal_ref !== value.dispatch.owner_principal_ref ||\n    value.reassignment.run_request_sha256 !== value.dispatch.run_request_sha256\n  )) {\n    context.addIssue({ code: "custom", path: ["reassignment"],\n      message: "Reassignment receipt is not bound to this terminal predecessor" });\n  }\n});\n''',
)

# Dispatch record codecs/readers.
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''  ComputerAgentDispatchDeclineReceiptSchema,\n  ComputerAgentDispatchSchema,\n''',
    '''  ComputerAgentDispatchDeclineReceiptSchema,\n  ComputerAgentDispatchReassignmentSchema,\n  ComputerAgentDispatchSchema,\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''  type ComputerAgentDispatchDeclineReceipt,\n} from "@eliotr/contracts";\n''',
    '''  type ComputerAgentDispatchDeclineReceipt,\n  type ComputerAgentDispatchReassignment,\n} from "@eliotr/contracts";\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export interface DeclineRow {\n  dispatch_id: string;\n  project_id: string;\n  connection_id: string;\n  connection_revision: number;\n  actor_issuer: string;\n  actor_subject: string;\n  credential_generation: string;\n  reason: string;\n  note: string | null;\n  idempotency_key: string;\n  request_sha256: string;\n  record_json: string;\n  record_sha256: string;\n  declined_at: string;\n}\n''',
    '''export interface DeclineRow {\n  dispatch_id: string;\n  project_id: string;\n  connection_id: string;\n  connection_revision: number;\n  actor_issuer: string;\n  actor_subject: string;\n  credential_generation: string;\n  reason: string;\n  note: string | null;\n  idempotency_key: string;\n  request_sha256: string;\n  record_json: string;\n  record_sha256: string;\n  declined_at: string;\n}\nexport interface ReassignmentRow {\n  predecessor_dispatch_id: string;\n  successor_dispatch_id: string;\n  project_id: string;\n  owner_principal_ref: string;\n  owner_credential_generation: string;\n  predecessor_state: string;\n  run_request_sha256: string;\n  successor_transport: string;\n  successor_route_revision: number;\n  successor_connection_id: string;\n  successor_connection_revision: number;\n  successor_client_grant_id: string;\n  successor_client_grant_revision: number;\n  idempotency_key: string;\n  request_sha256: string;\n  record_json: string;\n  record_sha256: string;\n  reassigned_at: string;\n}\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export async function readComputerAgentDispatchRow(\n''',
    '''export async function decodeComputerAgentDispatchReassignment(\n  row: ReassignmentRow,\n): Promise<ComputerAgentDispatchReassignment> {\n  let raw: unknown;\n  try { raw = JSON.parse(row.record_json); }\n  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,\n    "Dispatch reassignment is not valid JSON"); }\n  const parsed = ComputerAgentDispatchReassignmentSchema.safeParse(raw);\n  if (!parsed.success || canonicalJson(parsed.data) !== row.record_json ||\n      await sha256Utf8(row.record_json) !== row.record_sha256 ||\n      parsed.data.predecessor_dispatch_id !== row.predecessor_dispatch_id ||\n      parsed.data.successor_dispatch_id !== row.successor_dispatch_id ||\n      parsed.data.project_id !== row.project_id ||\n      parsed.data.owner_principal_ref !== row.owner_principal_ref ||\n      parsed.data.owner_credential_generation !== row.owner_credential_generation ||\n      parsed.data.predecessor_state !== row.predecessor_state ||\n      parsed.data.run_request_sha256 !== row.run_request_sha256 ||\n      parsed.data.successor_transport !== row.successor_transport ||\n      parsed.data.successor_route_revision !== row.successor_route_revision ||\n      parsed.data.successor_connection_id !== row.successor_connection_id ||\n      parsed.data.successor_connection_revision !== row.successor_connection_revision ||\n      parsed.data.successor_client_grant_id !== row.successor_client_grant_id ||\n      parsed.data.successor_client_grant_revision !== row.successor_client_grant_revision ||\n      parsed.data.idempotency_key !== row.idempotency_key ||\n      parsed.data.request_sha256 !== row.request_sha256 ||\n      parsed.data.reassigned_at !== row.reassigned_at) {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,\n      "Dispatch reassignment identity is corrupt");\n  }\n  return parsed.data;\n}\n\nexport async function readComputerAgentDispatchRow(\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export async function readCurrentComputerAgentDispatchOffer(\n''',
    '''export async function readComputerAgentDispatchReassignmentRow(\n  db: D1Database,\n  predecessorDispatchId: string,\n): Promise<ReassignmentRow | null> {\n  try {\n    return await db.prepare(\n      "SELECT * FROM computer_agent_dispatch_reassignment " +\n      "WHERE predecessor_dispatch_id=?1 LIMIT 1",\n    ).bind(predecessorDispatchId).first<ReassignmentRow>();\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,\n      "Dispatch reassignment read is unavailable", true);\n  }\n}\n\nexport async function readComputerAgentDispatchReassignmentReplay(\n  db: D1Database,\n  principal: string,\n  key: string,\n): Promise<ReassignmentRow | null> {\n  try {\n    return await db.prepare("SELECT * FROM computer_agent_dispatch_reassignment " +\n      "WHERE owner_principal_ref=?1 AND idempotency_key=?2 LIMIT 1")\n      .bind(principal, key).first<ReassignmentRow>();\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,\n      "Dispatch reassignment replay read is unavailable", true);\n  }\n}\n\nexport async function readCurrentComputerAgentDispatchOffer(\n''',
)

# Status includes immutable replacement truth.
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    '''  decodeComputerAgentDispatchDecline,\n  readComputerAgentDispatchAbandonmentRow,\n''',
    '''  decodeComputerAgentDispatchDecline,\n  decodeComputerAgentDispatchReassignment,\n  readComputerAgentDispatchAbandonmentRow,\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    '''  readComputerAgentDispatchDeclineRow,\n  readCurrentComputerAgentDispatchOffer,\n''',
    '''  readComputerAgentDispatchDeclineRow,\n  readComputerAgentDispatchReassignmentRow,\n  readCurrentComputerAgentDispatchOffer,\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    '''  const [acceptedRow, abandonedRow, declinedRow] = await Promise.all([\n    readComputerAgentDispatchAcceptanceRow(input.database, input.dispatch.dispatch_id),\n    readComputerAgentDispatchAbandonmentRow(input.database, input.dispatch.dispatch_id),\n    readComputerAgentDispatchDeclineRow(input.database, input.dispatch.dispatch_id),\n  ]);\n''',
    '''  const [acceptedRow, abandonedRow, declinedRow, reassignmentRow] = await Promise.all([\n    readComputerAgentDispatchAcceptanceRow(input.database, input.dispatch.dispatch_id),\n    readComputerAgentDispatchAbandonmentRow(input.database, input.dispatch.dispatch_id),\n    readComputerAgentDispatchDeclineRow(input.database, input.dispatch.dispatch_id),\n    readComputerAgentDispatchReassignmentRow(input.database, input.dispatch.dispatch_id),\n  ]);\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    '''  const decline = declinedRow === null ? null\n    : await decodeComputerAgentDispatchDecline(declinedRow);\n''',
    '''  const decline = declinedRow === null ? null\n    : await decodeComputerAgentDispatchDecline(declinedRow);\n  const reassignment = reassignmentRow === null ? null\n    : await decodeComputerAgentDispatchReassignment(reassignmentRow);\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts",
    '''    decline,\n  });\n''',
    '''    decline,\n    reassignment,\n  });\n''',
)

# All dispatch reads require the complete migration family once status includes reassignment.
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''const DECLINE_SCHEMA_GENERATION = "computer-agent-dispatch-decline-v1";\n''',
    '''const DECLINE_SCHEMA_GENERATION = "computer-agent-dispatch-decline-v1";\nconst REASSIGNMENT_SCHEMA_GENERATION = "computer-agent-dispatch-reassignment-v1";\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      "'computer_agent_dispatch_decline_generation')",\n''',
    '''      "'computer_agent_dispatch_decline_generation'," +\n      "'computer_agent_dispatch_reassignment_generation')",\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 through 0092 are required", true);\n  }\n''',
    '''  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 through 0093 are required", true);\n  }\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      values.get("computer_agent_dispatch_decline_generation") !==\n        DECLINE_SCHEMA_GENERATION) {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 through 0092 are required", true);\n''',
    '''      values.get("computer_agent_dispatch_decline_generation") !==\n        DECLINE_SCHEMA_GENERATION ||\n      values.get("computer_agent_dispatch_reassignment_generation") !==\n        REASSIGNMENT_SCHEMA_GENERATION) {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 through 0093 are required", true);\n''',
)

# HTTP route and dispatcher.
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-http.ts",
    '''import { createComputerAgentDispatchDeclineService } from "./computer-agent-dispatch-decline.js";\n''',
    '''import { createComputerAgentDispatchDeclineService } from "./computer-agent-dispatch-decline.js";\nimport { createComputerAgentDispatchReassignmentService } from "./computer-agent-dispatch-reassignment.js";\n''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-http.ts",
    '''    if (operation === "research.computer-agent-dispatches.abandon") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env,\n        await createComputerAgentDispatchAbandonmentService({ database: env.CORE_DB })\n          .abandon(context, params.project_id ?? "", params.dispatch_id ?? "",\n            await readJsonBodyWithinBytes(request, maximumBytes)));\n    }\n    requireJson(request);\n''',
    '''    if (operation === "research.computer-agent-dispatches.abandon") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env,\n        await createComputerAgentDispatchAbandonmentService({ database: env.CORE_DB })\n          .abandon(context, params.project_id ?? "", params.dispatch_id ?? "",\n            await readJsonBodyWithinBytes(request, maximumBytes)));\n    }\n    if (operation === "research.computer-agent-dispatches.reassign") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env,\n        await createComputerAgentDispatchReassignmentService(env).reassign(\n          context, params.project_id ?? "", params.dispatch_id ?? "",\n          await readJsonBodyWithinBytes(request, maximumBytes),\n        ));\n    }\n    requireJson(request);\n''',
)
replace_once(
    "apps/eliotr-core/src/http-special-routes.ts",
    '''    case "research.computer-agent-dispatches.abandon":\n    case "research.computer-agent-dispatches.status":\n''',
    '''    case "research.computer-agent-dispatches.abandon":\n    case "research.computer-agent-dispatches.reassign":\n    case "research.computer-agent-dispatches.status":\n''',
)
replace_once(
    "packages/interfaces/src/routes.ts",
    '''  { method: "POST", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/abandon", operation: "research.computer-agent-dispatches.abandon", auth: "owner", maximum_request_bytes: 4096, response_mode: "json" },\n''',
    '''  { method: "POST", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/abandon", operation: "research.computer-agent-dispatches.abandon", auth: "owner", maximum_request_bytes: 4096, response_mode: "json" },\n  { method: "POST", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/reassign", operation: "research.computer-agent-dispatches.reassign", auth: "owner", maximum_request_bytes: 8192, response_mode: "json" },\n''',
)

append_once(
    "docs/adr/0007-external-agents-and-cloudflare-evolution.md",
    "## 11. Explicit terminal dispatch reassignment",
    r'''
## 11. Explicit terminal dispatch reassignment

Migration 0093 adds an auditable owner action after an unaccepted dispatch has already settled as
`ABANDONED` or `DECLINED`. Reassignment reuses only the predecessor's frozen Research request and
`run_request_sha256`. The successor is created through the ordinary dispatch authority, so current route,
connection revision, transport, project grant, qualification, deployment and owner session are checked
again. The predecessor and successor receive distinct dispatch IDs, actor credential generations and any
later task/lease identities. Accepted, merely expired/stale, pending, mismatched or already-reassigned
dispatches are rejected. This is explicit failover history, not timeout automation or work transfer.
''',
)
append_once(
    "docs/implementation/muse-operator-runbook.md",
    "### Explicit terminal reassignment",
    r'''
### Explicit terminal reassignment

When a pending Spark, Muse, Dot or other offer has been immutably abandoned by the owner or declined by
the exact target, the owner may call the reassignment endpoint with the predecessor state and frozen
`run_request_sha256` it just read. The response links one new dispatch to that terminal predecessor. The
new target must independently satisfy the current route, grant and qualification checks. Do not reassign an
accepted run, infer failover from timeout alone, reuse the old dispatch ID, or transfer a task or lease.
''',
)
append_once(
    "docs/implementation/computer-agent-web-inbox.md",
    "### Owner reassignment API",
    r'''
### Owner reassignment API

The Web Inbox remains a target-agent surface. Owner automation uses
`POST /api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/reassign` after reading
an `ABANDONED` or `DECLINED` predecessor. The body names the exact expected predecessor state and frozen
request digest plus the newly selected route/connection/grant/transport. The successor is a new offer;
no browser secret, accepted run, task lease or credential authority is copied from the predecessor.
''',
)
