#!/usr/bin/env bash
set -euo pipefail
mkdir -p .github/scripts
gzip -dc .github/abandonment-payload/apply.py.gz > .github/scripts/apply-computer-agent-abandonment.py
python -m py_compile .github/scripts/apply-computer-agent-abandonment.py
python .github/scripts/apply-computer-agent-abandonment.py
git add -N \
  infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql \
  apps/eliotr-core/src/computer-agent-dispatch-abandonment.ts
git diff --check
python - <<'PY'
from pathlib import Path
import re
import subprocess

expected = {
    'infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql',
    'packages/contracts/src/computer-agent-dispatch.ts',
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    'apps/eliotr-core/src/computer-agent-dispatch-abandonment.ts',
    'apps/eliotr-core/src/computer-agent-dispatch-store.ts',
    'apps/eliotr-core/src/computer-agent-dispatch-http.ts',
    'apps/eliotr-core/src/http-special-routes.ts',
    'packages/interfaces/src/routes.ts',
    'docs/adr/0007-external-agents-and-cloudflare-evolution.md',
    'docs/adr/0008-computer-agent-web-inbox.md',
    'docs/implementation/computer-agent-web-inbox.md',
    'docs/implementation/muse-operator-runbook.md',
}
changed = set(subprocess.check_output(
    ['git', 'diff', '--name-only', '--diff-filter=AM'], text=True,
).splitlines())
if changed != expected:
    raise SystemExit(f'unexpected product diff: missing={sorted(expected-changed)} extra={sorted(changed-expected)}')
markers = {
    'infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql':
        'computer-agent-dispatch-abandonment-v1',
    'packages/contracts/src/computer-agent-dispatch.ts':
        'ComputerAgentDispatchAbandonmentSchema',
    'apps/eliotr-core/src/computer-agent-dispatch-abandonment.ts':
        'createComputerAgentDispatchAbandonmentService',
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts':
        'computer_agent_dispatch_offer_actionable',
    'packages/interfaces/src/routes.ts':
        'research.computer-agent-dispatches.abandon',
}
for name, marker in markers.items():
    text = Path(name).read_text(encoding='utf-8')
    if marker not in text:
        raise SystemExit(f'{name}: missing {marker}')
routes = Path('packages/interfaces/src/routes.ts').read_text(encoding='utf-8')
pairs = re.findall(r'\{ method: "([A-Z]+)", path: "([^"]+)"', routes)
if len(pairs) != len(set(pairs)):
    raise SystemExit('duplicate route method/path pair')
if routes.count('research.computer-agent-dispatches.abandon') != 1:
    raise SystemExit('abandon route count mismatch')
for name in changed:
    path = Path(name)
    if path.suffix not in {'.ts', '.tsx', '.js', '.mjs'} or '/src/' not in f'/{name}':
        continue
    current = len(path.read_text(encoding='utf-8').splitlines())
    old = subprocess.run(['git', 'show', f'HEAD:{name}'], text=True, capture_output=True)
    if old.returncode != 0 or len(old.stdout.splitlines()) <= 600:
        if current > 600:
            raise SystemExit(f'changed source exceeds 600 lines: {name} ({current})')
print('COMPUTER_AGENT_DISPATCH_ABANDONMENT_STATIC_OK')
PY
npm install --global pnpm@11.23.0 --ignore-scripts
pnpm install --frozen-lockfile --ignore-scripts
pnpm --filter @eliotr/contracts --filter @eliotr/interfaces --filter @eliotr/core typecheck
node --input-type=module <<'JS'
import {
  ComputerAgentDispatchAbandonSchema,
  ComputerAgentDispatchStatusSchema,
} from './packages/contracts/dist/computer-agent-dispatch.js';

const dispatch = {
  protocol: 'eliotr.computer-agent-dispatch.v1',
  dispatch_id: 'dispatch-1', project_id: 'project-1',
  task_kind: 'RESEARCH_BRANCH_ANALYSIS', transport: 'WEB_INBOX',
  route_revision: 1, priority: 0, connection_id: 'muse', connection_revision: 1,
  client_grant_id: 'grant-1', client_grant_revision: 1,
  owner_principal_ref: 'owner-1', owner_credential_generation: 'owner-gen-1',
  actor: { issuer: 'https://team.cloudflareaccess.com', authentication_method: 'service_token', subject: 'muse.access' },
  qualification: { challenge_id: 'challenge-1', observation_ref: 'observation-1',
    verified_credential_generation: 'agent-gen-1', ready_until: '2026-10-01T08:00:00.000Z',
    deployment_generation: 'deploy-1' },
  run_request: { query: 'Question?', product: 'RESEARCH',
    scope_expression: { kind: 'PROJECT', project_id: 'project-1' }, literals: [],
    evidence_grade: 'E1', budget_ref: 'research-budget-v1', max_results: 4,
    request_version: 'eliotr.research-run-request.v2',
    inquiry_protocol_ref: { id: 'protocol-1', revision: 1 } },
  run_request_sha256: 'a'.repeat(64), created_at: '2026-10-01T06:00:00.000Z',
  expires_at: '2026-10-01T07:00:00.000Z',
};
const abandonment = {
  protocol: 'eliotr.computer-agent-dispatch-abandoned.v1',
  dispatch_id: 'dispatch-1', project_id: 'project-1', owner_principal_ref: 'owner-1',
  owner_credential_generation: 'owner-gen-2', reason: 'OWNER_REASSIGNMENT',
  idempotency_key: 'abandon-1', request_sha256: 'b'.repeat(64),
  abandoned_at: '2026-10-01T06:10:00.000Z',
};
ComputerAgentDispatchStatusSchema.parse({
  protocol: 'eliotr.computer-agent-dispatch-status.v1', state: 'ABANDONED',
  dispatch, acceptance: null, abandonment,
});
let rejected = 0;
for (const value of [
  { protocol: 'eliotr.computer-agent-dispatch-status.v1', state: 'PENDING', dispatch, acceptance: null, abandonment },
  { protocol: 'eliotr.computer-agent-dispatch-status.v1', state: 'ACCEPTED', dispatch,
    acceptance: { protocol: 'eliotr.computer-agent-dispatch-accepted.v1', dispatch_id: 'dispatch-1',
      workflow_instance_id: 'run-1', investigation_ref: { id: 'inv-1', revision: 1 },
      connection_id: 'muse', connection_revision: 1, client_grant_id: 'grant-1',
      client_grant_revision: 1, actor: dispatch.actor, credential_generation: 'agent-gen-1',
      accepted_at: '2026-10-01T06:05:00.000Z' }, abandonment },
]) {
  try { ComputerAgentDispatchStatusSchema.parse(value); } catch { rejected += 1; }
}
if (rejected !== 2) throw new Error('invalid terminal-state combinations were accepted');
if (ComputerAgentDispatchAbandonSchema.safeParse({ reason: 'OTHER' }).success) {
  throw new Error('OTHER abandonment without note was accepted');
}
console.log('COMPUTER_AGENT_DISPATCH_ABANDONMENT_CONTRACT_OK');
JS
node infra/d1/check-expression-depth.mjs
python - <<'PY'
import hashlib
import json
import sqlite3
from pathlib import Path

db = sqlite3.connect(':memory:')
db.executescript('''
PRAGMA foreign_keys=ON;
CREATE TABLE schema_state(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE project_owner(project_id TEXT NOT NULL,principal_ref TEXT NOT NULL,
  PRIMARY KEY(project_id,principal_ref));
CREATE TABLE computer_agent_dispatch(
  dispatch_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,owner_principal_ref TEXT NOT NULL,
  created_at TEXT NOT NULL);
CREATE TABLE computer_agent_dispatch_acceptance(dispatch_id TEXT PRIMARY KEY
  REFERENCES computer_agent_dispatch(dispatch_id));
CREATE VIEW computer_agent_dispatch_offer_current AS
  SELECT d.* FROM computer_agent_dispatch d
  LEFT JOIN computer_agent_dispatch_acceptance a ON a.dispatch_id=d.dispatch_id
  WHERE a.dispatch_id IS NULL;
''')
db.executescript(Path('infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql').read_text())
db.execute("INSERT INTO project_owner VALUES ('project-1','owner-1')")
for name in ('dispatch-1','dispatch-2','dispatch-3'):
  db.execute("INSERT INTO computer_agent_dispatch VALUES (?,?,?,?)",
    (name,'project-1','owner-1','2026-10-01T06:00:00.000Z'))

def abandonment(dispatch, key, reason='OWNER_REASSIGNMENT'):
  record = {
    'protocol':'eliotr.computer-agent-dispatch-abandoned.v1',
    'dispatch_id':dispatch,'project_id':'project-1','owner_principal_ref':'owner-1',
    'owner_credential_generation':'owner-gen-1','reason':reason,
    'idempotency_key':key,'request_sha256':'a'*64,
    'abandoned_at':'2026-10-01T06:10:00.000Z',
  }
  text = json.dumps(record, sort_keys=True, separators=(',',':'))
  return (dispatch,'project-1','owner-1','owner-gen-1',reason,None,key,'a'*64,
    text,hashlib.sha256(text.encode()).hexdigest(),'2026-10-01T06:10:00.000Z')

sql = '''INSERT INTO computer_agent_dispatch_abandonment(
  dispatch_id,project_id,owner_principal_ref,owner_credential_generation,reason,note,
  idempotency_key,request_sha256,record_json,record_sha256,abandoned_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?)'''
db.execute(sql, abandonment('dispatch-1','abandon-1'))
assert db.execute("SELECT COUNT(*) FROM computer_agent_dispatch_offer_actionable WHERE dispatch_id='dispatch-1'").fetchone()[0] == 0
try:
  db.execute("INSERT INTO computer_agent_dispatch_acceptance VALUES ('dispatch-1')")
  raise AssertionError('abandoned dispatch was accepted')
except sqlite3.IntegrityError as error:
  assert 'COMPUTER_AGENT_DISPATCH_ABANDONED' in str(error)
try:
  db.execute(sql, abandonment('dispatch-2','abandon-1'))
  raise AssertionError('idempotency key was reused')
except sqlite3.IntegrityError:
  pass
db.execute("INSERT INTO computer_agent_dispatch_acceptance VALUES ('dispatch-3')")
try:
  db.execute(sql, abandonment('dispatch-3','abandon-3'))
  raise AssertionError('accepted dispatch was abandoned')
except sqlite3.IntegrityError as error:
  assert 'COMPUTER_AGENT_DISPATCH_ABANDONMENT_INVALID' in str(error)
try:
  db.execute("UPDATE computer_agent_dispatch_abandonment SET reason='OWNER_CANCELLED' WHERE dispatch_id='dispatch-1'")
  raise AssertionError('abandonment was mutated')
except sqlite3.IntegrityError:
  pass
assert db.execute("SELECT COUNT(*) FROM computer_agent_dispatch").fetchone()[0] == 3
assert db.execute("SELECT value FROM schema_state WHERE key='computer_agent_dispatch_abandonment_generation'").fetchone()[0] == 'computer-agent-dispatch-abandonment-v1'
print('COMPUTER_AGENT_DISPATCH_ABANDONMENT_SQL_OK')
PY
set +e
node scripts/check-budgets.mjs > "$RUNNER_TEMP/abandonment-budget-report.txt" 2>&1
set -e
cat "$RUNNER_TEMP/abandonment-budget-report.txt"
BUDGET_REPORT="$RUNNER_TEMP/abandonment-budget-report.txt" python - <<'PY'
from pathlib import Path
import os
report = Path(os.environ['BUDGET_REPORT']).read_text()
if 'Source budgets: PASS' in report:
    print('COMPUTER_AGENT_DISPATCH_ABANDONMENT_GLOBAL_BUDGETS_PASS')
    raise SystemExit(0)
known = {
    'packages/cloudflare-ai/src/dynamic-route-qualification.ts',
    'packages/cloudflare-ai/src/dynamic-route-rest-codec.ts',
    'packages/cloudflare-ai/src/model-gateway-response.ts',
    'packages/cloudflare-ai',
    'packages/cloudflare-artifacts/src/artifact-draft-reader-core.ts',
    'packages/cloudflare-research/src/research-owner-qualification-renewal.ts',
    'packages/cloudflare-research/src/research-report-admission.ts',
    'packages/cloudflare-research',
    'packages/cloudflare-research-stages/src/research-claim-audit-input.ts',
    'apps/eliotr-core/src/http.ts',
    'apps/eliotr-core/src/research-semantic-composition.ts',
    'apps/eliotr-core/src/wiki-publication-store.ts',
    'apps/eliotr-core',
    'Worker source',
    'apps/eliotr-pwa',
}
observed = set()
for line in report.splitlines():
    if ' has ' in line and (' lines (max ' in line or ' source lines (max ' in line):
        observed.add(line.split(' has ', 1)[0])
    elif line.startswith('Worker source is '):
        observed.add('Worker source')
unknown = observed - known
if unknown:
    raise SystemExit(f'abandonment introduced new budget violations: {sorted(unknown)}')
if not observed:
    raise SystemExit('unrecognized source-budget report')
print(f'COMPUTER_AGENT_DISPATCH_ABANDONMENT_SCOPED_BUDGET_OK known_debt={len(observed)} new_violations=0')
PY
git fetch origin main
test "$(git rev-parse HEAD)" = "$(git rev-parse origin/main)"
git rm -f \
  .github/workflows/apply-computer-agent-abandonment.yml \
  .github/abandonment-payload/apply.py.gz \
  .github/abandonment-payload/runner.sh.gz
rm -f .github/scripts/apply-computer-agent-abandonment.py
git diff --check
git add \
  infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql \
  packages/contracts/src/computer-agent-dispatch.ts \
  apps/eliotr-core/src/computer-agent-dispatch-record.ts \
  apps/eliotr-core/src/computer-agent-dispatch-abandonment.ts \
  apps/eliotr-core/src/computer-agent-dispatch-store.ts \
  apps/eliotr-core/src/computer-agent-dispatch-http.ts \
  apps/eliotr-core/src/http-special-routes.ts \
  packages/interfaces/src/routes.ts \
  docs/adr/0007-external-agents-and-cloudflare-evolution.md \
  docs/adr/0008-computer-agent-web-inbox.md \
  docs/implementation/computer-agent-web-inbox.md \
  docs/implementation/muse-operator-runbook.md
git config user.name 'Iurii Lisenkov'
git config user.email '71514792+UnknownAlienHuman@users.noreply.github.com'
git commit -m 'feat: abandon pending computer-agent dispatches' \
  -m 'Add immutable owner abandonment for one unaccepted exact dispatch. Remove abandoned offers from Spark, Muse, Dot or other target actors and require a new readiness observation plus a distinct dispatch for reassignment. Accepted runs remain under existing Research cancel/recover authority; no automatic failover or task/lease transfer. Refs #301.'
git push origin HEAD:main
