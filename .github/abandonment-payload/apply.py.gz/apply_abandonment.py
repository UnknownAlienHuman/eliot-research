from pathlib import Path
from textwrap import dedent

ROOT = Path(__file__).resolve().parents[2]


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(dedent(content).lstrip(), encoding='utf-8')


def replace_once(path: str, old: str, new: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding='utf-8')
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'{path}: expected one replacement, found {count}: {old[:100]!r}')
    target.write_text(text.replace(old, new), encoding='utf-8')


def append_once(path: str, marker: str, content: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding='utf-8')
    if marker in text:
        return
    target.write_text(text.rstrip() + '\n\n' + dedent(content).strip() + '\n', encoding='utf-8')

write('infra/d1/core/migrations/0091_computer_agent_dispatch_abandonment.sql', r'''
-- Explicit owner abandonment of an unaccepted computer-agent dispatch.
-- Abandonment closes one exact offer; it never creates a replacement or transfers a task/lease.
PRAGMA foreign_keys = ON;

CREATE TABLE computer_agent_dispatch_abandonment (
  dispatch_id TEXT PRIMARY KEY REFERENCES computer_agent_dispatch(dispatch_id),
  project_id TEXT NOT NULL CHECK(length(project_id) BETWEEN 1 AND 256),
  owner_principal_ref TEXT NOT NULL CHECK(length(owner_principal_ref) BETWEEN 1 AND 256),
  owner_credential_generation TEXT NOT NULL CHECK(length(owner_credential_generation) BETWEEN 1 AND 256),
  reason TEXT NOT NULL CHECK(reason IN (
    'TARGET_UNAVAILABLE','QUALIFICATION_EXPIRED','ROUTE_CHANGED',
    'OWNER_REASSIGNMENT','OWNER_CANCELLED','OTHER'
  )),
  note TEXT CHECK(note IS NULL OR length(note) BETWEEN 1 AND 2048),
  idempotency_key TEXT NOT NULL CHECK(length(idempotency_key) BETWEEN 1 AND 256),
  request_sha256 TEXT NOT NULL
    CHECK(length(request_sha256)=64 AND request_sha256 NOT GLOB '*[^0-9a-f]*'),
  record_json TEXT NOT NULL
    CHECK(json_valid(record_json) AND length(CAST(record_json AS BLOB)) BETWEEN 1 AND 32768),
  record_sha256 TEXT NOT NULL
    CHECK(length(record_sha256)=64 AND record_sha256 NOT GLOB '*[^0-9a-f]*'),
  abandoned_at TEXT NOT NULL CHECK(julianday(abandoned_at) IS NOT NULL),
  UNIQUE(owner_principal_ref,idempotency_key),
  CHECK(reason<>'OTHER' OR note IS NOT NULL),
  CHECK(json_extract(record_json,'$.protocol') IS 'eliotr.computer-agent-dispatch-abandoned.v1'),
  CHECK(json_extract(record_json,'$.dispatch_id') IS dispatch_id),
  CHECK(json_extract(record_json,'$.project_id') IS project_id),
  CHECK(json_extract(record_json,'$.owner_principal_ref') IS owner_principal_ref),
  CHECK(json_extract(record_json,'$.owner_credential_generation') IS owner_credential_generation),
  CHECK(json_extract(record_json,'$.reason') IS reason),
  CHECK((note IS NULL AND json_type(record_json,'$.note') IS NULL)
    OR json_extract(record_json,'$.note') IS note),
  CHECK(json_extract(record_json,'$.idempotency_key') IS idempotency_key),
  CHECK(json_extract(record_json,'$.request_sha256') IS request_sha256),
  CHECK(json_extract(record_json,'$.abandoned_at') IS abandoned_at)
) STRICT;

CREATE INDEX computer_agent_dispatch_abandonment_owner_idx
  ON computer_agent_dispatch_abandonment(owner_principal_ref,abandoned_at DESC,dispatch_id DESC);

CREATE TRIGGER computer_agent_dispatch_abandonment_insert_guard
BEFORE INSERT ON computer_agent_dispatch_abandonment
WHEN NOT EXISTS (
  SELECT 1
  FROM computer_agent_dispatch d
  JOIN project_owner o
    ON o.project_id=d.project_id AND o.principal_ref=d.owner_principal_ref
  LEFT JOIN computer_agent_dispatch_acceptance a ON a.dispatch_id=d.dispatch_id
  WHERE d.dispatch_id=NEW.dispatch_id
    AND d.project_id=NEW.project_id
    AND d.owner_principal_ref=NEW.owner_principal_ref
    AND a.dispatch_id IS NULL
    AND julianday(NEW.abandoned_at)>=julianday(d.created_at)
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_ABANDONMENT_INVALID'); END;

CREATE TRIGGER computer_agent_dispatch_abandonment_no_update
BEFORE UPDATE ON computer_agent_dispatch_abandonment
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_ABANDONMENT_IMMUTABLE'); END;
CREATE TRIGGER computer_agent_dispatch_abandonment_no_delete
BEFORE DELETE ON computer_agent_dispatch_abandonment
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_ABANDONMENT_IMMUTABLE'); END;

-- SQLite serializes writers; whichever immutable terminal record wins first excludes the other.
CREATE TRIGGER computer_agent_dispatch_acceptance_abandonment_guard
BEFORE INSERT ON computer_agent_dispatch_acceptance
WHEN EXISTS (
  SELECT 1 FROM computer_agent_dispatch_abandonment x
  WHERE x.dispatch_id=NEW.dispatch_id
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_ABANDONED'); END;

CREATE VIEW computer_agent_dispatch_offer_actionable AS
SELECT o.*
FROM computer_agent_dispatch_offer_current o
LEFT JOIN computer_agent_dispatch_abandonment x ON x.dispatch_id=o.dispatch_id
WHERE x.dispatch_id IS NULL;

INSERT INTO schema_state(key,value,updated_at)
VALUES('computer_agent_dispatch_abandonment_generation',
  'computer-agent-dispatch-abandonment-v1',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
''')

replace_once(
    'packages/contracts/src/computer-agent-dispatch.ts',
    'const revision = z.number().int().min(1).max(2_147_483_647);\nconst question = z.string().min(1)\n',
    'const revision = z.number().int().min(1).max(2_147_483_647);\n'
    'const actionKey = z.string().min(1).max(256)\n'
    '  .regex(/^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$/u);\n'
    'const question = z.string().min(1)\n',
)

replace_once(
    'packages/contracts/src/computer-agent-dispatch.ts',
    '''export type ComputerAgentDispatchAcceptance =\n  z.infer<typeof ComputerAgentDispatchAcceptanceSchema>;\n\nexport const ComputerAgentDispatchStateSchema = z.enum([\n  "PENDING", "ACCEPTED", "EXPIRED", "STALE",\n]);\n''',
    '''export type ComputerAgentDispatchAcceptance =\n  z.infer<typeof ComputerAgentDispatchAcceptanceSchema>;\n\nexport const ComputerAgentDispatchAbandonReasonSchema = z.enum([\n  "TARGET_UNAVAILABLE", "QUALIFICATION_EXPIRED", "ROUTE_CHANGED",\n  "OWNER_REASSIGNMENT", "OWNER_CANCELLED", "OTHER",\n]);\nexport type ComputerAgentDispatchAbandonReason =\n  z.infer<typeof ComputerAgentDispatchAbandonReasonSchema>;\n\nexport const ComputerAgentDispatchAbandonSchema = z.object({\n  reason: ComputerAgentDispatchAbandonReasonSchema,\n  note: z.string().min(1).max(2048).optional(),\n}).strict().superRefine((value, context) => {\n  if (value.reason === "OTHER" && value.note === undefined) {\n    context.addIssue({ code: "custom", path: ["note"],\n      message: "OTHER abandonment requires a note" });\n  }\n});\n\nexport const ComputerAgentDispatchAbandonmentSchema = z.object({\n  protocol: z.literal("eliotr.computer-agent-dispatch-abandoned.v1"),\n  dispatch_id: id,\n  project_id: id,\n  owner_principal_ref: id,\n  owner_credential_generation: id,\n  reason: ComputerAgentDispatchAbandonReasonSchema,\n  note: z.string().min(1).max(2048).optional(),\n  idempotency_key: actionKey,\n  request_sha256: Sha256Schema,\n  abandoned_at: IsoDateTimeSchema,\n}).strict().superRefine((value, context) => {\n  if (value.reason === "OTHER" && value.note === undefined) {\n    context.addIssue({ code: "custom", path: ["note"],\n      message: "OTHER abandonment requires a note" });\n  }\n});\nexport type ComputerAgentDispatchAbandonment =\n  z.infer<typeof ComputerAgentDispatchAbandonmentSchema>;\n\nexport const ComputerAgentDispatchStateSchema = z.enum([\n  "PENDING", "ACCEPTED", "ABANDONED", "EXPIRED", "STALE",\n]);\n''',
)

replace_once(
    'packages/contracts/src/computer-agent-dispatch.ts',
    '''  acceptance: ComputerAgentDispatchAcceptanceSchema.nullable(),\n}).strict().superRefine((value, context) => {\n  if ((value.state === "ACCEPTED") !== (value.acceptance !== null)) {\n    context.addIssue({ code: "custom", path: ["acceptance"],\n      message: "Only ACCEPTED dispatch status may contain an acceptance receipt" });\n  }\n  if (value.acceptance !== null && value.acceptance.dispatch_id !== value.dispatch.dispatch_id) {\n    context.addIssue({ code: "custom", path: ["acceptance", "dispatch_id"],\n      message: "Acceptance receipt is bound to another dispatch" });\n  }\n});\n''',
    '''  acceptance: ComputerAgentDispatchAcceptanceSchema.nullable(),\n  abandonment: ComputerAgentDispatchAbandonmentSchema.nullable(),\n}).strict().superRefine((value, context) => {\n  if ((value.state === "ACCEPTED") !== (value.acceptance !== null)) {\n    context.addIssue({ code: "custom", path: ["acceptance"],\n      message: "Only ACCEPTED dispatch status may contain an acceptance receipt" });\n  }\n  if ((value.state === "ABANDONED") !== (value.abandonment !== null)) {\n    context.addIssue({ code: "custom", path: ["abandonment"],\n      message: "Only ABANDONED dispatch status may contain an abandonment receipt" });\n  }\n  if (value.acceptance !== null && value.abandonment !== null) {\n    context.addIssue({ code: "custom", message: "Dispatch cannot be accepted and abandoned" });\n  }\n  if (value.acceptance !== null && value.acceptance.dispatch_id !== value.dispatch.dispatch_id) {\n    context.addIssue({ code: "custom", path: ["acceptance", "dispatch_id"],\n      message: "Acceptance receipt is bound to another dispatch" });\n  }\n  if (value.abandonment !== null && (\n    value.abandonment.dispatch_id !== value.dispatch.dispatch_id ||\n    value.abandonment.project_id !== value.dispatch.project_id\n  )) {\n    context.addIssue({ code: "custom", path: ["abandonment", "dispatch_id"],\n      message: "Abandonment receipt is bound to another dispatch" });\n  }\n});\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    '''  ComputerAgentDispatchAcceptanceSchema,\n  ComputerAgentDispatchSchema,\n  type ComputerAgentDispatch,\n  type ComputerAgentDispatchAcceptance,\n''',
    '''  ComputerAgentDispatchAbandonmentSchema,\n  ComputerAgentDispatchAcceptanceSchema,\n  ComputerAgentDispatchSchema,\n  type ComputerAgentDispatch,\n  type ComputerAgentDispatchAbandonment,\n  type ComputerAgentDispatchAcceptance,\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    '''export interface AcceptanceRow {\n  dispatch_id: string;\n  workflow_instance_id: string;\n  investigation_id: string;\n  investigation_revision: number;\n  actor_issuer: string;\n  actor_subject: string;\n  credential_generation: string;\n  record_json: string;\n  record_sha256: string;\n  accepted_at: string;\n}\n''',
    '''export interface AcceptanceRow {\n  dispatch_id: string;\n  workflow_instance_id: string;\n  investigation_id: string;\n  investigation_revision: number;\n  actor_issuer: string;\n  actor_subject: string;\n  credential_generation: string;\n  record_json: string;\n  record_sha256: string;\n  accepted_at: string;\n}\nexport interface AbandonmentRow {\n  dispatch_id: string;\n  project_id: string;\n  owner_principal_ref: string;\n  owner_credential_generation: string;\n  reason: string;\n  note: string | null;\n  idempotency_key: string;\n  request_sha256: string;\n  record_json: string;\n  record_sha256: string;\n  abandoned_at: string;\n}\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    '''export async function readComputerAgentDispatchRow(\n''',
    '''export async function decodeComputerAgentDispatchAbandonment(\n  row: AbandonmentRow,\n): Promise<ComputerAgentDispatchAbandonment> {\n  let raw: unknown;\n  try { raw = JSON.parse(row.record_json); }\n  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,\n    "Dispatch abandonment is not valid JSON"); }\n  const parsed = ComputerAgentDispatchAbandonmentSchema.safeParse(raw);\n  if (!parsed.success || canonicalJson(parsed.data) !== row.record_json ||\n      await sha256Utf8(row.record_json) !== row.record_sha256 ||\n      parsed.data.dispatch_id !== row.dispatch_id || parsed.data.project_id !== row.project_id ||\n      parsed.data.owner_principal_ref !== row.owner_principal_ref ||\n      parsed.data.owner_credential_generation !== row.owner_credential_generation ||\n      parsed.data.reason !== row.reason || (parsed.data.note ?? null) !== row.note ||\n      parsed.data.idempotency_key !== row.idempotency_key ||\n      parsed.data.request_sha256 !== row.request_sha256 ||\n      parsed.data.abandoned_at !== row.abandoned_at) {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,\n      "Dispatch abandonment identity is corrupt");\n  }\n  return parsed.data;\n}\n\nexport async function readComputerAgentDispatchRow(\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    '''export async function readCurrentComputerAgentDispatchOffer(\n''',
    '''export async function readComputerAgentDispatchAbandonmentRow(\n  db: D1Database,\n  dispatchId: string,\n): Promise<AbandonmentRow | null> {\n  try {\n    return await db.prepare(\n      "SELECT * FROM computer_agent_dispatch_abandonment WHERE dispatch_id=?1 LIMIT 1",\n    ).bind(dispatchId).first<AbandonmentRow>();\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,\n      "Dispatch abandonment read is unavailable", true);\n  }\n}\n\nexport async function readComputerAgentDispatchAbandonmentReplay(\n  db: D1Database,\n  principal: string,\n  key: string,\n): Promise<AbandonmentRow | null> {\n  try {\n    return await db.prepare("SELECT * FROM computer_agent_dispatch_abandonment " +\n      "WHERE owner_principal_ref=?1 AND idempotency_key=?2 LIMIT 1")\n      .bind(principal, key).first<AbandonmentRow>();\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,\n      "Dispatch abandonment replay read is unavailable", true);\n  }\n}\n\nexport async function readCurrentComputerAgentDispatchOffer(\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-record.ts',
    '"SELECT * FROM computer_agent_dispatch_offer_current WHERE dispatch_id=?1 LIMIT 1",',
    '"SELECT * FROM computer_agent_dispatch_offer_actionable WHERE dispatch_id=?1 LIMIT 1",',
)

write('apps/eliotr-core/src/computer-agent-dispatch-abandonment.ts', r'''
import {
  ComputerAgentDispatchAbandonSchema,
  ComputerAgentDispatchAbandonmentSchema,
  type ComputerAgentDispatchAbandonment,
} from "@eliotr/contracts";
import type { AuthenticatedRequestContext } from "@eliotr/interfaces";
import { canonicalJson, sha256Utf8 } from "@eliotr/platform-cloudflare";
import {
  decodeComputerAgentDispatch,
  decodeComputerAgentDispatchAbandonment,
  readComputerAgentDispatchAbandonmentReplay,
  readComputerAgentDispatchAbandonmentRow,
  readComputerAgentDispatchAcceptanceRow,
  readComputerAgentDispatchRow,
} from "./computer-agent-dispatch-record.js";
import {
  failComputerAgentDispatch as fail,
} from "./computer-agent-dispatch-error.js";

const SCHEMA_GENERATION = "computer-agent-dispatch-abandonment-v1";
const ID = /^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,255}$/u;
const KEY = /^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$/u;

function identifier(value: unknown, label: string): string {
  if (typeof value !== "string" || !ID.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400, `${label} is invalid`);
  }
  return value;
}
function idempotency(value: unknown): string {
  if (typeof value !== "string" || !KEY.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
      "Idempotency-Key is required and invalid");
  }
  return value;
}
function instant(now: () => number): number {
  let value: number;
  try { value = now(); }
  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
    "Dispatch abandonment clock is unavailable", true); }
  if (!Number.isSafeInteger(value) || value < 0) {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Dispatch abandonment clock is invalid", true);
  }
  return value;
}
function owner(context: AuthenticatedRequestContext, now: () => number) {
  const current = instant(now);
  if (context.client_class !== "owner_pwa" || context.request.signal.aborted) {
    fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
      "A current owner request is required");
  }
  if (context.access && (context.access.principal_ref !== context.principal_ref ||
      context.access.credential_generation !== context.credential_generation ||
      !Number.isFinite(Date.parse(context.access.expires_at)) ||
      Date.parse(context.access.expires_at) <= current)) {
    fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
      "Owner session is no longer current");
  }
  return Object.freeze({
    principal_ref: identifier(context.principal_ref, "owner principal"),
    credential_generation: identifier(context.credential_generation, "owner credential generation"),
  });
}
async function requireSchema(db: D1Database): Promise<void> {
  let value: string | null;
  try {
    value = await db.prepare(
      "SELECT value FROM schema_state WHERE key='computer_agent_dispatch_abandonment_generation'",
    ).first<string>("value");
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch abandonment migration 0091 is required", true);
  }
  if (value !== SCHEMA_GENERATION) {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch abandonment migration 0091 is required", true);
  }
}
async function requireProjectOwner(
  db: D1Database,
  projectId: string,
  principal: string,
): Promise<void> {
  let row: unknown;
  try {
    row = await db.prepare(
      "SELECT 1 FROM project_owner WHERE project_id=?1 AND principal_ref=?2 LIMIT 1",
    ).bind(projectId, principal).first();
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Project owner authority read is unavailable", true);
  }
  if (row === null) {
    fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
      "Current project owner authority is required");
  }
}

export function createComputerAgentDispatchAbandonmentService(options: {
  readonly database: D1Database;
  readonly now?: () => number;
}) {
  const db = options.database;
  const now = options.now ?? Date.now;

  async function abandon(
    context: AuthenticatedRequestContext,
    projectIdValue: string,
    dispatchIdValue: string,
    rawInput: unknown,
  ): Promise<ComputerAgentDispatchAbandonment> {
    await requireSchema(db);
    const identity = owner(context, now);
    const projectId = identifier(projectIdValue, "project_id");
    const dispatchId = identifier(dispatchIdValue, "dispatch_id");
    const parsed = ComputerAgentDispatchAbandonSchema.safeParse(rawInput);
    if (!parsed.success) {
      fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
        "Dispatch abandonment contains unknown or invalid fields");
    }
    const key = idempotency(context.request.headers.get("Idempotency-Key"));
    await requireProjectOwner(db, projectId, identity.principal_ref);
    const row = await readComputerAgentDispatchRow(db, dispatchId);
    if (row === null || row.project_id !== projectId) {
      fail("COMPUTER_AGENT_DISPATCH_NOT_FOUND", 404,
        "Computer-agent dispatch does not exist in this project");
    }
    const dispatch = await decodeComputerAgentDispatch(row);
    if (dispatch.owner_principal_ref !== identity.principal_ref) {
      fail("COMPUTER_AGENT_DISPATCH_OWNER_REQUIRED", 403,
        "Dispatch belongs to another project owner");
    }
    const requestSha = await sha256Utf8(canonicalJson({
      protocol: "eliotr.computer-agent-dispatch-abandon-request.v1",
      dispatch_id: dispatch.dispatch_id,
      project_id: projectId,
      owner_principal_ref: identity.principal_ref,
      idempotency_key: key,
      input: parsed.data,
    }));
    const replay = await readComputerAgentDispatchAbandonmentReplay(
      db, identity.principal_ref, key,
    );
    if (replay !== null) {
      if (replay.dispatch_id !== dispatch.dispatch_id || replay.project_id !== projectId ||
          replay.request_sha256 !== requestSha) {
        fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
          "Idempotency-Key is already bound to another dispatch abandonment");
      }
      owner(context, now);
      return decodeComputerAgentDispatchAbandonment(replay);
    }
    const existing = await readComputerAgentDispatchAbandonmentRow(db, dispatch.dispatch_id);
    if (existing !== null) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Dispatch was already abandoned by another immutable action");
    }
    if (await readComputerAgentDispatchAcceptanceRow(db, dispatch.dispatch_id) !== null) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Accepted dispatch cannot be abandoned; cancel the existing Research run instead");
    }
    const abandonedAt = new Date(instant(now)).toISOString();
    const abandonment = ComputerAgentDispatchAbandonmentSchema.parse({
      protocol: "eliotr.computer-agent-dispatch-abandoned.v1",
      dispatch_id: dispatch.dispatch_id,
      project_id: projectId,
      owner_principal_ref: identity.principal_ref,
      owner_credential_generation: identity.credential_generation,
      reason: parsed.data.reason,
      ...(parsed.data.note === undefined ? {} : { note: parsed.data.note }),
      idempotency_key: key,
      request_sha256: requestSha,
      abandoned_at: abandonedAt,
    });
    const record = canonicalJson(abandonment);
    const digest = await sha256Utf8(record);
    owner(context, now);
    try {
      await db.prepare("INSERT INTO computer_agent_dispatch_abandonment(" +
        "dispatch_id,project_id,owner_principal_ref,owner_credential_generation,reason,note," +
        "idempotency_key,request_sha256,record_json,record_sha256,abandoned_at) " +
        "VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11)")
        .bind(abandonment.dispatch_id, abandonment.project_id,
          abandonment.owner_principal_ref, abandonment.owner_credential_generation,
          abandonment.reason, abandonment.note ?? null, abandonment.idempotency_key,
          abandonment.request_sha256, record, digest, abandonment.abandoned_at).run();
    } catch { /* Immutable readback below reconciles lost acknowledgements and races. */ }
    const settled = await readComputerAgentDispatchAbandonmentRow(db, dispatch.dispatch_id);
    if (settled === null) {
      fail("COMPUTER_AGENT_DISPATCH_SETTLEMENT_UNCERTAIN", 503,
        "Dispatch abandonment receipt is unavailable; retry with the same Idempotency-Key", true);
    }
    if (settled.request_sha256 !== requestSha ||
        settled.idempotency_key !== key) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Dispatch settled another abandonment action");
    }
    const decoded = await decodeComputerAgentDispatchAbandonment(settled);
    if (canonicalJson(decoded) !== record) {
      fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
        "Dispatch abandonment readback differs from the intended record");
    }
    owner(context, now);
    return decoded;
  }

  return { abandon };
}
''')

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-store.ts',
    '''  decodeComputerAgentDispatch,\n  decodeComputerAgentDispatchAcceptance,\n  readComputerAgentDispatchAcceptanceRow,\n''',
    '''  decodeComputerAgentDispatch,\n  decodeComputerAgentDispatchAbandonment,\n  decodeComputerAgentDispatchAcceptance,\n  readComputerAgentDispatchAbandonmentRow,\n  readComputerAgentDispatchAcceptanceRow,\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-store.ts',
    'const SCHEMA_GENERATION = "computer-agent-dispatch-v1";\n',
    'const SCHEMA_GENERATION = "computer-agent-dispatch-v1";\n'
    'const ABANDONMENT_SCHEMA_GENERATION = "computer-agent-dispatch-abandonment-v1";\n',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-store.ts',
    '''async function requireSchema(db: D1Database): Promise<void> {\n  let value: string | null;\n  try {\n    value = await db.prepare(\n      "SELECT value FROM schema_state WHERE key='computer_agent_dispatch_generation'",\n    ).first<string>("value");\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migration 0090 is required", true);\n  }\n  if (value !== SCHEMA_GENERATION) {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migration 0090 is required", true);\n  }\n}\n''',
    '''async function requireSchema(db: D1Database): Promise<void> {\n  let values: Map<string, string>;\n  try {\n    const result = await db.prepare(\n      "SELECT key,value FROM schema_state WHERE key IN (" +\n      "'computer_agent_dispatch_generation','computer_agent_dispatch_abandonment_generation')",\n    ).all<{ key: string; value: string }>();\n    values = new Map((result.results ?? []).map((entry) => [entry.key, entry.value]));\n  } catch {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 and 0091 are required", true);\n  }\n  if (values.get("computer_agent_dispatch_generation") !== SCHEMA_GENERATION ||\n      values.get("computer_agent_dispatch_abandonment_generation") !==\n        ABANDONMENT_SCHEMA_GENERATION) {\n    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,\n      "Computer-agent dispatch migrations 0090 and 0091 are required", true);\n  }\n}\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-store.ts',
    '''    const acceptedRow = await readComputerAgentDispatchAcceptanceRow(db, dispatchId);\n    const acceptance = acceptedRow === null ? null\n      : await decodeComputerAgentDispatchAcceptance(acceptedRow);\n    const state = acceptance !== null ? "ACCEPTED" as const\n      : Date.parse(dispatch.expires_at) <= instant(now) ? "EXPIRED" as const\n        : await readCurrentComputerAgentDispatchOffer(db, dispatchId) === null\n          ? "STALE" as const : "PENDING" as const;\n    owner(context, now);\n    return ComputerAgentDispatchStatusSchema.parse({\n      protocol: "eliotr.computer-agent-dispatch-status.v1", state, dispatch, acceptance,\n    });\n''',
    '''    const [acceptedRow, abandonedRow] = await Promise.all([\n      readComputerAgentDispatchAcceptanceRow(db, dispatchId),\n      readComputerAgentDispatchAbandonmentRow(db, dispatchId),\n    ]);\n    const acceptance = acceptedRow === null ? null\n      : await decodeComputerAgentDispatchAcceptance(acceptedRow);\n    const abandonment = abandonedRow === null ? null\n      : await decodeComputerAgentDispatchAbandonment(abandonedRow);\n    if (acceptance !== null && abandonment !== null) {\n      fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,\n        "Dispatch is both accepted and abandoned");\n    }\n    const state = acceptance !== null ? "ACCEPTED" as const\n      : abandonment !== null ? "ABANDONED" as const\n        : Date.parse(dispatch.expires_at) <= instant(now) ? "EXPIRED" as const\n          : await readCurrentComputerAgentDispatchOffer(db, dispatchId) === null\n            ? "STALE" as const : "PENDING" as const;\n    owner(context, now);\n    return ComputerAgentDispatchStatusSchema.parse({\n      protocol: "eliotr.computer-agent-dispatch-status.v1",\n      state, dispatch, acceptance, abandonment,\n    });\n''',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-http.ts',
    'import { createComputerAgentDispatchService } from "./computer-agent-dispatch-store.js";\n',
    'import { createComputerAgentDispatchService } from "./computer-agent-dispatch-store.js";\n'
    'import { createComputerAgentDispatchAbandonmentService } from "./computer-agent-dispatch-abandonment.js";\n',
)

replace_once(
    'apps/eliotr-core/src/computer-agent-dispatch-http.ts',
    '''    if (operation === "research.computer-agent-dispatches.create") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env, await service.create(\n        context,\n        params.project_id ?? "",\n        await readJsonBodyWithinBytes(request, maximumBytes),\n      ));\n    }\n    requireJson(request);\n''',
    '''    if (operation === "research.computer-agent-dispatches.create") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env, await service.create(\n        context,\n        params.project_id ?? "",\n        await readJsonBodyWithinBytes(request, maximumBytes),\n      ));\n    }\n    if (operation === "research.computer-agent-dispatches.abandon") {\n      requireOwnerMutationOrigin(request, url);\n      return apiResult(request, env,\n        await createComputerAgentDispatchAbandonmentService({ database: env.CORE_DB })\n          .abandon(context, params.project_id ?? "", params.dispatch_id ?? "",\n            await readJsonBodyWithinBytes(request, maximumBytes)));\n    }\n    requireJson(request);\n''',
)

replace_once(
    'apps/eliotr-core/src/http-special-routes.ts',
    '''    case "research.computer-agent-dispatches.create":\n    case "research.computer-agent-dispatches.status":\n''',
    '''    case "research.computer-agent-dispatches.create":\n    case "research.computer-agent-dispatches.abandon":\n    case "research.computer-agent-dispatches.status":\n''',
)

replace_once(
    'packages/interfaces/src/routes.ts',
    '''  { method: "GET", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id", operation: "research.computer-agent-dispatches.status", auth: "owner", maximum_request_bytes: 0, response_mode: "json" },\n''',
    '''  { method: "GET", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id", operation: "research.computer-agent-dispatches.status", auth: "owner", maximum_request_bytes: 0, response_mode: "json" },\n  { method: "POST", path: "/api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/abandon", operation: "research.computer-agent-dispatches.abandon", auth: "owner", maximum_request_bytes: 4096, response_mode: "json" },\n''',
)

append_once('docs/adr/0007-external-agents-and-cloudflare-evolution.md',
  '## Explicit abandonment and reassignment', r'''
## Explicit abandonment and reassignment

A pending exact dispatch may be closed only by an immutable owner abandonment receipt. The owner then
re-reads route readiness and creates a distinct dispatch for the selected READY Spark, Muse, Dot or other
connection. The system does not choose the replacement, reuse the old dispatch identity, transfer a task
or lease, or let an abandoned dispatch be accepted. An accepted dispatch cannot be abandoned; its
existing Research run is controlled through the ordinary status/cancel/recover authority.
''')

append_once('docs/adr/0008-computer-agent-web-inbox.md',
  '### Reassignment after a declined or unavailable target', r'''
### Reassignment after a declined or unavailable target

The web inbox never silently advances to the next route entry. For an unaccepted offer, the owner records
an explicit abandonment, observes current readiness again, and creates another exact dispatch. This
preserves actor, credential-generation and grant boundaries. Accepted work uses the existing Research
cancellation/recovery flow instead of reassignment.
''')

append_once('docs/implementation/computer-agent-web-inbox.md',
  '## Deliberate reassignment', r'''
## Deliberate reassignment

For an unaccepted dispatch that should not run, call the owner endpoint
`POST /api/v1/research/projects/:project_id/computer-agent-dispatches/:dispatch_id/abandon` with a stable
`Idempotency-Key` and `{ "reason": "OWNER_REASSIGNMENT" }` or another declared reason. Then read route
readiness and create a new dispatch with a new idempotency key for the chosen READY entry. Do not give the
replacement actor the old dispatch ID, task ID, lease ID or credential generation. Accepted dispatches
must be cancelled through the existing Research run controls.
''')

append_once('docs/implementation/muse-operator-runbook.md',
  '### Owner-directed reassignment', r'''
### Owner-directed reassignment

If a pending Spark, Muse or Dot dispatch should not be accepted, the owner abandons that exact offer and
creates a new dispatch only after re-reading current readiness. Agents never infer that a timeout grants
them another actor's work, and a replacement never reuses the old dispatch, task, lease or credential
identity. Once accepted, use ordinary Research status/cancel/recover rather than dispatch reassignment.
''')
