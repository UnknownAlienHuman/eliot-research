#!/usr/bin/env bash
set -euo pipefail

BASELINE="cca6982de00fddf27b6422a8b1df6864a5dc43b1"
if [[ "$(git rev-parse HEAD)" != "$BASELINE" ]]; then
  echo "unexpected baseline: $(git rev-parse HEAD)" >&2
  exit 1
fi

mkdir -p .github/scripts
gzip -dc .github/decline-payload/apply.py.gz > .github/scripts/apply-computer-agent-decline.py
python -m py_compile .github/scripts/apply-computer-agent-decline.py

touch \
  infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql \
  apps/eliotr-core/src/computer-agent-dispatch-decline.ts \
  apps/eliotr-core/src/computer-agent-dispatch-status.ts
git add -N \
  infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql \
  apps/eliotr-core/src/computer-agent-dispatch-decline.ts \
  apps/eliotr-core/src/computer-agent-dispatch-status.ts

python .github/scripts/apply-computer-agent-decline.py
git diff --check

python - <<'PY'
from pathlib import Path
import re
import subprocess

required = {
    "infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql": [
        "computer_agent_dispatch_offer_claimable",
        "computer_agent_dispatch_decline_insert_guard",
        "computer_agent_dispatch_acceptance_decline_guard",
        "computer_agent_dispatch_abandonment_decline_guard",
    ],
    "packages/contracts/src/computer-agent-dispatch.ts": [
        "ComputerAgentDispatchDeclineReceiptSchema",
        '"DECLINED"',
    ],
    "apps/eliotr-core/src/computer-agent-dispatch-decline.ts": [
        "createComputerAgentDispatchDeclineService",
        "verified service-token actor",
    ],
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts": [
        "readComputerAgentDispatchDeclineRow",
        "computer_agent_dispatch_offer_claimable",
    ],
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts": [
        "computer_agent_dispatch_offer_claimable",
        "computer_agent_dispatch_decline_generation",
    ],
    "apps/eliotr-core/src/computer-agent-dispatch-status.ts": [
        '"DECLINED"',
        "terminalCount",
    ],
    "apps/eliotr-pwa/src/agent-inbox-dispatch.ts": [
        "decline-dispatch",
        "/decline",
    ],
}
for name, markers in required.items():
    text = Path(name).read_text(encoding="utf-8")
    for marker in markers:
        if marker not in text:
            raise SystemExit(f"{name}: missing {marker}")

routes = Path("packages/interfaces/src/routes.ts").read_text(encoding="utf-8")
pairs = re.findall(r'\{ method: "([A-Z]+)", path: "([^"]+)"', routes)
if len(pairs) != len(set(pairs)):
    raise SystemExit("duplicate HTTP route")
if routes.count("research.computer-agent-dispatches.decline") != 1:
    raise SystemExit("decline route count mismatch")

changed = subprocess.check_output(
    ["git", "diff", "--name-only", "--diff-filter=AM"], text=True,
).splitlines()
for name in changed:
    path = Path(name)
    if path.suffix not in {".ts", ".tsx", ".js", ".mjs"} or "/src/" not in f"/{name}":
        continue
    current = len(path.read_text(encoding="utf-8").splitlines())
    old = subprocess.run(["git", "show", f"HEAD:{name}"], text=True, capture_output=True)
    if old.returncode != 0:
        if current > 600:
            raise SystemExit(f"new source exceeds 600 lines: {name} ({current})")
    elif len(old.stdout.splitlines()) <= 600 and current > 600:
        raise SystemExit(f"changed source created a new violation: {name} ({current})")
print("COMPUTER_AGENT_DISPATCH_DECLINE_STATIC_OK")
PY

npm install --global pnpm@11.23.0 --ignore-scripts
pnpm install --frozen-lockfile --ignore-scripts
pnpm --filter @eliotr/contracts --filter @eliotr/interfaces --filter @eliotr/core --filter @eliotr/pwa typecheck
pnpm --filter @eliotr/pwa check
pnpm --filter @eliotr/pwa build

node --input-type=module <<'JS'
import {
  ComputerAgentDispatchDeclineSchema,
  ComputerAgentDispatchStatusSchema,
} from "./packages/contracts/dist/computer-agent-dispatch.js";

const dispatch = {
  protocol: "eliotr.computer-agent-dispatch.v1",
  dispatch_id: "dispatch-1",
  project_id: "project-1",
  task_kind: "RESEARCH_BRANCH_ANALYSIS",
  transport: "WEB_INBOX",
  route_revision: 1,
  priority: 0,
  connection_id: "dot",
  connection_revision: 1,
  client_grant_id: "grant-1",
  client_grant_revision: 1,
  owner_principal_ref: "owner-1",
  owner_credential_generation: "owner-generation-1",
  actor: {
    issuer: "https://access.example.test",
    authentication_method: "service_token",
    subject: "dot-client.access",
  },
  qualification: {
    challenge_id: "challenge-1",
    observation_ref: "observation-1",
    verified_credential_generation: "agent-generation-1",
    ready_until: "2026-10-01T08:00:00.000Z",
    deployment_generation: "deployment-1",
  },
  run_request: {
    query: "Compare the admitted evidence branches.",
    product: "RESEARCH",
    scope_expression: { kind: "PROJECT", project_id: "project-1" },
    literals: [],
    evidence_grade: "E1",
    budget_ref: "research-budget-v1",
    max_results: 8,
    request_version: "eliotr.research-run-request.v2",
    inquiry_protocol_ref: { id: "inquiry-protocol-1", revision: 1 },
  },
  run_request_sha256: "a".repeat(64),
  created_at: "2026-10-01T06:00:00.000Z",
  expires_at: "2026-10-01T07:00:00.000Z",
};
const decline = {
  protocol: "eliotr.computer-agent-dispatch-declined.v1",
  dispatch_id: "dispatch-1",
  project_id: "project-1",
  connection_id: "dot",
  connection_revision: 1,
  actor: dispatch.actor,
  credential_generation: "agent-generation-1",
  reason: "UNAVAILABLE",
  idempotency_key: "decline-1",
  request_sha256: "b".repeat(64),
  declined_at: "2026-10-01T06:05:00.000Z",
};
ComputerAgentDispatchStatusSchema.parse({
  protocol: "eliotr.computer-agent-dispatch-status.v1",
  state: "DECLINED",
  dispatch,
  acceptance: null,
  abandonment: null,
  decline,
});
if (ComputerAgentDispatchDeclineSchema.safeParse({ reason: "OTHER" }).success) {
  throw new Error("OTHER decline without note was accepted");
}
const acceptance = {
  protocol: "eliotr.computer-agent-dispatch-accepted.v1",
  dispatch_id: "dispatch-1",
  workflow_instance_id: "workflow-1",
  investigation_ref: { id: "investigation-1", revision: 1 },
  connection_id: "dot",
  connection_revision: 1,
  client_grant_id: "grant-1",
  client_grant_revision: 1,
  actor: dispatch.actor,
  credential_generation: "agent-generation-1",
  accepted_at: "2026-10-01T06:05:00.000Z",
};
if (ComputerAgentDispatchStatusSchema.safeParse({
  protocol: "eliotr.computer-agent-dispatch-status.v1",
  state: "ACCEPTED",
  dispatch,
  acceptance,
  abandonment: null,
  decline,
}).success) {
  throw new Error("conflicting terminal receipts were accepted");
}
console.log("COMPUTER_AGENT_DISPATCH_DECLINE_CONTRACT_OK");
JS

python infra/d1/check-expression-depth.py

python - <<'PY'
import json
import sqlite3
from pathlib import Path

db = sqlite3.connect(":memory:")
db.execute("PRAGMA foreign_keys=ON")
db.executescript("""
CREATE TABLE schema_state(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
) STRICT;
CREATE TABLE computer_agent_dispatch(
  dispatch_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  connection_id TEXT NOT NULL,
  connection_revision INTEGER NOT NULL,
  actor_issuer TEXT NOT NULL,
  actor_subject TEXT NOT NULL,
  qualification_credential_generation TEXT NOT NULL,
  created_at TEXT NOT NULL
) STRICT;
CREATE TABLE computer_agent_dispatch_acceptance(
  dispatch_id TEXT PRIMARY KEY REFERENCES computer_agent_dispatch(dispatch_id)
) STRICT;
CREATE TABLE computer_agent_dispatch_abandonment(
  dispatch_id TEXT PRIMARY KEY REFERENCES computer_agent_dispatch(dispatch_id)
) STRICT;
CREATE VIEW computer_agent_dispatch_offer_actionable AS
SELECT d.*
FROM computer_agent_dispatch d
LEFT JOIN computer_agent_dispatch_acceptance a ON a.dispatch_id=d.dispatch_id
LEFT JOIN computer_agent_dispatch_abandonment x ON x.dispatch_id=d.dispatch_id
WHERE a.dispatch_id IS NULL AND x.dispatch_id IS NULL;
""")
migration = Path("infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql").read_text()
db.executescript(migration)

def add_dispatch(name, generation="generation-1"):
    db.execute(
        "INSERT INTO computer_agent_dispatch VALUES(?,?,?,?,?,?,?,?)",
        (name, "project-1", "dot", 1, "issuer-1", "subject-1",
         generation, "2026-10-01T06:00:00.000Z"),
    )

def decline(name, key, generation="generation-1"):
    record = {
        "protocol": "eliotr.computer-agent-dispatch-declined.v1",
        "dispatch_id": name,
        "project_id": "project-1",
        "connection_id": "dot",
        "connection_revision": 1,
        "actor": {
            "issuer": "issuer-1",
            "authentication_method": "service_token",
            "subject": "subject-1",
        },
        "credential_generation": generation,
        "reason": "UNAVAILABLE",
        "idempotency_key": key,
        "request_sha256": "a" * 64,
        "declined_at": "2026-10-01T06:05:00.000Z",
    }
    db.execute(
        "INSERT INTO computer_agent_dispatch_decline VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (name, "project-1", "dot", 1, "issuer-1", "subject-1",
         generation, "UNAVAILABLE", None, key, "a" * 64,
         json.dumps(record, separators=(",", ":")), "b" * 64,
         "2026-10-01T06:05:00.000Z"),
    )

add_dispatch("dispatch-declined")
decline("dispatch-declined", "decline-1")
assert db.execute(
    "SELECT count(*) FROM computer_agent_dispatch_offer_claimable WHERE dispatch_id=?",
    ("dispatch-declined",),
).fetchone()[0] == 0
for table in ("computer_agent_dispatch_acceptance", "computer_agent_dispatch_abandonment"):
    try:
        db.execute(f"INSERT INTO {table}(dispatch_id) VALUES(?)", ("dispatch-declined",))
    except sqlite3.IntegrityError:
        pass
    else:
        raise SystemExit(f"{table} accepted a declined dispatch")

add_dispatch("dispatch-accepted")
db.execute("INSERT INTO computer_agent_dispatch_acceptance VALUES(?)", ("dispatch-accepted",))
try:
    decline("dispatch-accepted", "decline-accepted")
except sqlite3.IntegrityError:
    pass
else:
    raise SystemExit("decline accepted an accepted dispatch")

add_dispatch("dispatch-abandoned")
db.execute("INSERT INTO computer_agent_dispatch_abandonment VALUES(?)", ("dispatch-abandoned",))
try:
    decline("dispatch-abandoned", "decline-abandoned")
except sqlite3.IntegrityError:
    pass
else:
    raise SystemExit("decline accepted an abandoned dispatch")

add_dispatch("dispatch-wrong-generation")
try:
    decline("dispatch-wrong-generation", "decline-wrong-generation", "generation-2")
except sqlite3.IntegrityError:
    pass
else:
    raise SystemExit("decline accepted another credential generation")

add_dispatch("dispatch-actionable")
assert db.execute(
    "SELECT count(*) FROM computer_agent_dispatch_offer_claimable WHERE dispatch_id=?",
    ("dispatch-actionable",),
).fetchone()[0] == 1

try:
    db.execute(
        "UPDATE computer_agent_dispatch_decline SET reason='OTHER' WHERE dispatch_id='dispatch-declined'"
    )
except sqlite3.IntegrityError:
    pass
else:
    raise SystemExit("decline record was mutable")

print("COMPUTER_AGENT_DISPATCH_DECLINE_SQL_OK")
PY

set +e
node scripts/check-budgets.mjs > "$RUNNER_TEMP/decline-budget-report.txt" 2>&1
set -e
cat "$RUNNER_TEMP/decline-budget-report.txt"
BUDGET_REPORT="$RUNNER_TEMP/decline-budget-report.txt" python - <<'PY'
from pathlib import Path
import os

report = Path(os.environ["BUDGET_REPORT"]).read_text()
if "Source budgets: PASS" in report:
    print("COMPUTER_AGENT_DISPATCH_DECLINE_GLOBAL_BUDGETS_PASS")
    raise SystemExit(0)
known = {
    "packages/cloudflare-ai/src/dynamic-route-qualification.ts",
    "packages/cloudflare-ai/src/dynamic-route-rest-codec.ts",
    "packages/cloudflare-ai/src/model-gateway-response.ts",
    "packages/cloudflare-ai",
    "packages/cloudflare-artifacts/src/artifact-draft-reader-core.ts",
    "packages/cloudflare-research/src/research-owner-qualification-renewal.ts",
    "packages/cloudflare-research/src/research-report-admission.ts",
    "packages/cloudflare-research",
    "packages/cloudflare-research-stages/src/research-claim-audit-input.ts",
    "apps/eliotr-core/src/http.ts",
    "apps/eliotr-core/src/research-semantic-composition.ts",
    "apps/eliotr-core/src/wiki-publication-store.ts",
    "apps/eliotr-core",
    "Worker source",
    "apps/eliotr-pwa",
}
observed = set()
for line in report.splitlines():
    if " has " in line and (" lines (max " in line or " source lines (max " in line):
        observed.add(line.split(" has ", 1)[0])
    elif line.startswith("Worker source is "):
        observed.add("Worker source")
unknown = observed - known
if unknown:
    raise SystemExit(f"decline introduced new source-budget violations: {sorted(unknown)}")
if not observed:
    raise SystemExit("unrecognized source-budget report")
print(f"COMPUTER_AGENT_DISPATCH_DECLINE_SCOPED_BUDGET_OK known_debt={len(observed)} new_violations=0")
PY

git fetch origin main
if [[ "$(git rev-parse origin/main)" != "$BASELINE" ]]; then
  echo "origin/main moved during verification" >&2
  exit 1
fi

git rm \
  .github/workflows/apply-computer-agent-decline.yml \
  .github/decline-payload/apply.py.gz \
  .github/decline-payload/runner.sh.gz
rm -f .github/scripts/apply-computer-agent-decline.py

git add \
  infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql \
  packages/contracts/src/computer-agent-dispatch.ts \
  apps/eliotr-core/src/computer-agent-dispatch-decline.ts \
  apps/eliotr-core/src/computer-agent-dispatch-status.ts \
  apps/eliotr-core/src/computer-agent-dispatch-record.ts \
  apps/eliotr-core/src/computer-agent-dispatch-store.ts \
  apps/eliotr-core/src/computer-agent-dispatch-http.ts \
  apps/eliotr-core/src/http-special-routes.ts \
  packages/interfaces/src/routes.ts \
  apps/eliotr-pwa/src/agent-inbox-dispatch.ts \
  apps/eliotr-pwa/src/pages/agent-inbox.astro \
  docs/adr/0007-external-agents-and-cloudflare-evolution.md \
  docs/adr/0008-computer-agent-web-inbox.md \
  docs/implementation/computer-agent-web-inbox.md \
  docs/implementation/muse-operator-runbook.md

git diff --cached --check
git config user.name "Iurii Lisenkov"
git config user.email "71514792+UnknownAlienHuman@users.noreply.github.com"
git commit -m "feat: let target agents decline dispatches" \
  -m "Allow the exact selected Spark, Muse, Dot or other service actor credential generation to immutably decline an unaccepted dispatch. Remove declined and abandoned offers from both point and queue pull reads, keep acceptance/abandonment/decline mutually exclusive, and expose the operation in the no-persistence web inbox. Reassignment remains an explicit new owner dispatch; no automatic failover or lease transfer. Refs #301."
git push origin HEAD:main
