
from pathlib import Path
from textwrap import dedent

ROOT = Path(__file__).resolve().parents[2]

def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(dedent(content).lstrip(), encoding="utf-8")

def replace_once(path: str, old: str, new: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one replacement, found {count}: {old[:120]!r}")
    target.write_text(text.replace(old, new), encoding="utf-8")

def replace_tail(path: str, marker: str, replacement: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    count = text.count(marker)
    if count != 1:
        raise SystemExit(f"{path}: expected one tail marker, found {count}: {marker!r}")
    prefix = text.split(marker, 1)[0]
    target.write_text(prefix + dedent(replacement).lstrip(), encoding="utf-8")

def append_once(path: str, marker: str, content: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    if marker in text:
        return
    target.write_text(text.rstrip() + "\n\n" + dedent(content).strip() + "\n", encoding="utf-8")

write("infra/d1/core/migrations/0092_computer_agent_dispatch_decline.sql", r'''
-- Exact target-actor decline of an unaccepted computer-agent dispatch.
-- Decline closes one offer. It never selects a replacement or transfers work, leases or credentials.
PRAGMA foreign_keys = ON;

CREATE TABLE computer_agent_dispatch_decline (
  dispatch_id TEXT PRIMARY KEY REFERENCES computer_agent_dispatch(dispatch_id),
  project_id TEXT NOT NULL CHECK(length(project_id) BETWEEN 1 AND 256),
  connection_id TEXT NOT NULL CHECK(length(connection_id) BETWEEN 1 AND 256),
  connection_revision INTEGER NOT NULL CHECK(connection_revision BETWEEN 1 AND 2147483647),
  actor_issuer TEXT NOT NULL CHECK(length(actor_issuer) BETWEEN 1 AND 256),
  actor_subject TEXT NOT NULL CHECK(length(actor_subject) BETWEEN 1 AND 256),
  credential_generation TEXT NOT NULL CHECK(length(credential_generation) BETWEEN 1 AND 256),
  reason TEXT NOT NULL CHECK(reason IN (
    'UNAVAILABLE','UNSUPPORTED_TASK','INSUFFICIENT_CONTEXT',
    'LOCAL_POLICY','TRANSIENT_FAILURE','OTHER'
  )),
  note TEXT CHECK(note IS NULL OR length(note) BETWEEN 1 AND 2048),
  idempotency_key TEXT NOT NULL CHECK(length(idempotency_key) BETWEEN 1 AND 256),
  request_sha256 TEXT NOT NULL
    CHECK(length(request_sha256)=64 AND request_sha256 NOT GLOB '*[^0-9a-f]*'),
  record_json TEXT NOT NULL
    CHECK(json_valid(record_json) AND length(CAST(record_json AS BLOB)) BETWEEN 1 AND 32768),
  record_sha256 TEXT NOT NULL
    CHECK(length(record_sha256)=64 AND record_sha256 NOT GLOB '*[^0-9a-f]*'),
  declined_at TEXT NOT NULL CHECK(julianday(declined_at) IS NOT NULL),
  UNIQUE(actor_issuer,actor_subject,idempotency_key),
  CHECK(reason<>'OTHER' OR note IS NOT NULL),
  CHECK(json_extract(record_json,'$.protocol') IS 'eliotr.computer-agent-dispatch-declined.v1'),
  CHECK(json_extract(record_json,'$.dispatch_id') IS dispatch_id),
  CHECK(json_extract(record_json,'$.project_id') IS project_id),
  CHECK(json_extract(record_json,'$.connection_id') IS connection_id),
  CHECK(json_extract(record_json,'$.connection_revision') IS connection_revision),
  CHECK(json_extract(record_json,'$.actor.issuer') IS actor_issuer),
  CHECK(json_extract(record_json,'$.actor.authentication_method') IS 'service_token'),
  CHECK(json_extract(record_json,'$.actor.subject') IS actor_subject),
  CHECK(json_extract(record_json,'$.credential_generation') IS credential_generation),
  CHECK(json_extract(record_json,'$.reason') IS reason),
  CHECK((note IS NULL AND json_type(record_json,'$.note') IS NULL)
    OR json_extract(record_json,'$.note') IS note),
  CHECK(json_extract(record_json,'$.idempotency_key') IS idempotency_key),
  CHECK(json_extract(record_json,'$.request_sha256') IS request_sha256),
  CHECK(json_extract(record_json,'$.declined_at') IS declined_at)
) STRICT;

CREATE INDEX computer_agent_dispatch_decline_actor_idx
  ON computer_agent_dispatch_decline(
    actor_issuer,actor_subject,declined_at DESC,dispatch_id DESC
  );

CREATE TRIGGER computer_agent_dispatch_decline_insert_guard
BEFORE INSERT ON computer_agent_dispatch_decline
WHEN NOT EXISTS (
  SELECT 1
  FROM computer_agent_dispatch d
  LEFT JOIN computer_agent_dispatch_acceptance a ON a.dispatch_id=d.dispatch_id
  LEFT JOIN computer_agent_dispatch_abandonment x ON x.dispatch_id=d.dispatch_id
  WHERE d.dispatch_id=NEW.dispatch_id
    AND d.project_id=NEW.project_id
    AND d.connection_id=NEW.connection_id
    AND d.connection_revision=NEW.connection_revision
    AND d.actor_issuer=NEW.actor_issuer
    AND d.actor_subject=NEW.actor_subject
    AND d.qualification_credential_generation=NEW.credential_generation
    AND a.dispatch_id IS NULL
    AND x.dispatch_id IS NULL
    AND julianday(NEW.declined_at)>=julianday(d.created_at)
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_DECLINE_INVALID'); END;

CREATE TRIGGER computer_agent_dispatch_decline_no_update
BEFORE UPDATE ON computer_agent_dispatch_decline
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_DECLINE_IMMUTABLE'); END;
CREATE TRIGGER computer_agent_dispatch_decline_no_delete
BEFORE DELETE ON computer_agent_dispatch_decline
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_DECLINE_IMMUTABLE'); END;

-- SQLite serializes writers; whichever immutable terminal record wins first excludes the others.
CREATE TRIGGER computer_agent_dispatch_acceptance_decline_guard
BEFORE INSERT ON computer_agent_dispatch_acceptance
WHEN EXISTS (
  SELECT 1 FROM computer_agent_dispatch_decline x
  WHERE x.dispatch_id=NEW.dispatch_id
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_DECLINED'); END;

CREATE TRIGGER computer_agent_dispatch_abandonment_decline_guard
BEFORE INSERT ON computer_agent_dispatch_abandonment
WHEN EXISTS (
  SELECT 1 FROM computer_agent_dispatch_decline x
  WHERE x.dispatch_id=NEW.dispatch_id
)
BEGIN SELECT RAISE(ABORT,'COMPUTER_AGENT_DISPATCH_DECLINED'); END;

CREATE VIEW computer_agent_dispatch_offer_claimable AS
SELECT o.*
FROM computer_agent_dispatch_offer_actionable o
LEFT JOIN computer_agent_dispatch_decline x ON x.dispatch_id=o.dispatch_id
WHERE x.dispatch_id IS NULL;

INSERT INTO schema_state(key,value,updated_at)
VALUES('computer_agent_dispatch_decline_generation',
  'computer-agent-dispatch-decline-v1',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
''')

replace_tail(
    "packages/contracts/src/computer-agent-dispatch.ts",
    'export const ComputerAgentDispatchStateSchema = z.enum([',
    r'''
export const ComputerAgentDispatchDeclineReasonSchema = z.enum([
  "UNAVAILABLE", "UNSUPPORTED_TASK", "INSUFFICIENT_CONTEXT",
  "LOCAL_POLICY", "TRANSIENT_FAILURE", "OTHER",
]);
export type ComputerAgentDispatchDeclineReason =
  z.infer<typeof ComputerAgentDispatchDeclineReasonSchema>;

export const ComputerAgentDispatchDeclineSchema = z.object({
  reason: ComputerAgentDispatchDeclineReasonSchema,
  note: z.string().min(1).max(2048).optional(),
}).strict().superRefine((value, context) => {
  if (value.reason === "OTHER" && value.note === undefined) {
    context.addIssue({ code: "custom", path: ["note"],
      message: "OTHER decline requires a note" });
  }
});

export const ComputerAgentDispatchDeclineReceiptSchema = z.object({
  protocol: z.literal("eliotr.computer-agent-dispatch-declined.v1"),
  dispatch_id: id,
  project_id: id,
  connection_id: id,
  connection_revision: revision,
  actor: ComputerAgentActorSchema,
  credential_generation: id,
  reason: ComputerAgentDispatchDeclineReasonSchema,
  note: z.string().min(1).max(2048).optional(),
  idempotency_key: actionKey,
  request_sha256: Sha256Schema,
  declined_at: IsoDateTimeSchema,
}).strict().superRefine((value, context) => {
  if (value.reason === "OTHER" && value.note === undefined) {
    context.addIssue({ code: "custom", path: ["note"],
      message: "OTHER decline requires a note" });
  }
});
export type ComputerAgentDispatchDeclineReceipt =
  z.infer<typeof ComputerAgentDispatchDeclineReceiptSchema>;

export const ComputerAgentDispatchStateSchema = z.enum([
  "PENDING", "ACCEPTED", "ABANDONED", "DECLINED", "EXPIRED", "STALE",
]);

export const ComputerAgentDispatchStatusSchema = z.object({
  protocol: z.literal("eliotr.computer-agent-dispatch-status.v1"),
  state: ComputerAgentDispatchStateSchema,
  dispatch: ComputerAgentDispatchSchema,
  acceptance: ComputerAgentDispatchAcceptanceSchema.nullable(),
  abandonment: ComputerAgentDispatchAbandonmentSchema.nullable(),
  decline: ComputerAgentDispatchDeclineReceiptSchema.nullable(),
}).strict().superRefine((value, context) => {
  if ((value.state === "ACCEPTED") !== (value.acceptance !== null)) {
    context.addIssue({ code: "custom", path: ["acceptance"],
      message: "Only ACCEPTED dispatch status may contain an acceptance receipt" });
  }
  if ((value.state === "ABANDONED") !== (value.abandonment !== null)) {
    context.addIssue({ code: "custom", path: ["abandonment"],
      message: "Only ABANDONED dispatch status may contain an abandonment receipt" });
  }
  if ((value.state === "DECLINED") !== (value.decline !== null)) {
    context.addIssue({ code: "custom", path: ["decline"],
      message: "Only DECLINED dispatch status may contain a decline receipt" });
  }
  const terminalCount = Number(value.acceptance !== null) +
    Number(value.abandonment !== null) + Number(value.decline !== null);
  if (terminalCount > 1) {
    context.addIssue({ code: "custom",
      message: "Dispatch terminal receipts are mutually exclusive" });
  }
  if (value.acceptance !== null && value.acceptance.dispatch_id !== value.dispatch.dispatch_id) {
    context.addIssue({ code: "custom", path: ["acceptance", "dispatch_id"],
      message: "Acceptance receipt is bound to another dispatch" });
  }
  if (value.abandonment !== null && (
    value.abandonment.dispatch_id !== value.dispatch.dispatch_id ||
    value.abandonment.project_id !== value.dispatch.project_id
  )) {
    context.addIssue({ code: "custom", path: ["abandonment", "dispatch_id"],
      message: "Abandonment receipt is bound to another dispatch" });
  }
  if (value.decline !== null && (
    value.decline.dispatch_id !== value.dispatch.dispatch_id ||
    value.decline.project_id !== value.dispatch.project_id ||
    value.decline.connection_id !== value.dispatch.connection_id ||
    value.decline.connection_revision !== value.dispatch.connection_revision ||
    value.decline.actor.issuer !== value.dispatch.actor.issuer ||
    value.decline.actor.subject !== value.dispatch.actor.subject
  )) {
    context.addIssue({ code: "custom", path: ["decline", "dispatch_id"],
      message: "Decline receipt is bound to another dispatch target" });
  }
});
export type ComputerAgentDispatchStatus = z.infer<typeof ComputerAgentDispatchStatusSchema>;
''',
)

write("apps/eliotr-core/src/computer-agent-dispatch-decline.ts", r'''
import {
  ComputerAgentDispatchDeclineReceiptSchema,
  ComputerAgentDispatchDeclineSchema,
  type ComputerAgentDispatchDeclineReceipt,
} from "@eliotr/contracts";
import type { AuthenticatedRequestContext } from "@eliotr/interfaces";
import { canonicalJson, sha256Utf8 } from "@eliotr/platform-cloudflare";
import {
  decodeComputerAgentDispatch,
  decodeComputerAgentDispatchDecline,
  readComputerAgentDispatchAbandonmentRow,
  readComputerAgentDispatchAcceptanceRow,
  readComputerAgentDispatchDeclineReplay,
  readComputerAgentDispatchDeclineRow,
  readComputerAgentDispatchRow,
} from "./computer-agent-dispatch-record.js";
import { failComputerAgentDispatch as fail } from "./computer-agent-dispatch-error.js";

const SCHEMA_GENERATION = "computer-agent-dispatch-decline-v1";
const ID = /^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,255}$/u;
const KEY = /^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$/u;

function identifier(value: unknown, label: string): string {
  if (typeof value !== "string" || !ID.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400, `${label} is invalid`);
  }
  return value;
}
function idempotency(value: unknown): string {
  if (typeof value !== "string" || !KEY.test(value)) {
    fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
      "Idempotency-Key is required and invalid");
  }
  return value;
}
function instant(now: () => number): number {
  let value: number;
  try { value = now(); }
  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
    "Dispatch decline clock is unavailable", true); }
  if (!Number.isSafeInteger(value) || value < 0) {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Dispatch decline clock is invalid", true);
  }
  return value;
}
function serviceIdentity(context: AuthenticatedRequestContext, now: () => number) {
  const current = instant(now);
  const access = context.access;
  if ((context.client_class !== "trusted_agent" &&
      context.client_class !== "named_api_client") ||
      access === undefined || access.authentication_method !== "service_token" ||
      typeof access.issuer !== "string" ||
      access.principal_ref !== context.principal_ref ||
      access.credential_generation !== context.credential_generation ||
      !Number.isFinite(Date.parse(access.expires_at)) ||
      Date.parse(access.expires_at) <= current ||
      context.request.signal.aborted) {
    fail("COMPUTER_AGENT_DISPATCH_SERVICE_REQUIRED", 403,
      "A current verified service-token actor is required");
  }
  return Object.freeze({
    issuer: identifier(access.issuer, "actor issuer"),
    subject: identifier(context.principal_ref, "actor subject"),
    credential_generation: identifier(context.credential_generation,
      "actor credential generation"),
  });
}
async function requireSchema(db: D1Database): Promise<void> {
  let value: string | null;
  try {
    value = await db.prepare(
      "SELECT value FROM schema_state WHERE key='computer_agent_dispatch_decline_generation'",
    ).first<string>("value");
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch decline migration 0092 is required", true);
  }
  if (value !== SCHEMA_GENERATION) {
    fail("COMPUTER_AGENT_DISPATCH_SCHEMA_NOT_READY", 503,
      "Computer-agent dispatch decline migration 0092 is required", true);
  }
}

export function createComputerAgentDispatchDeclineService(options: {
  readonly database: D1Database;
  readonly now?: () => number;
}) {
  const db = options.database;
  const now = options.now ?? Date.now;

  async function decline(
    context: AuthenticatedRequestContext,
    dispatchIdValue: string,
    rawInput: unknown,
  ): Promise<ComputerAgentDispatchDeclineReceipt> {
    await requireSchema(db);
    const identity = serviceIdentity(context, now);
    const dispatchId = identifier(dispatchIdValue, "dispatch_id");
    const parsed = ComputerAgentDispatchDeclineSchema.safeParse(rawInput);
    if (!parsed.success) {
      fail("COMPUTER_AGENT_DISPATCH_INPUT_INVALID", 400,
        "Dispatch decline contains unknown or invalid fields");
    }
    const key = idempotency(context.request.headers.get("Idempotency-Key"));
    const row = await readComputerAgentDispatchRow(db, dispatchId);
    if (row === null) {
      fail("COMPUTER_AGENT_DISPATCH_NOT_FOUND", 404,
        "Computer-agent dispatch does not exist");
    }
    const dispatch = await decodeComputerAgentDispatch(row);
    if (dispatch.actor.issuer !== identity.issuer ||
        dispatch.actor.subject !== identity.subject ||
        dispatch.qualification.verified_credential_generation !==
          identity.credential_generation) {
      fail("COMPUTER_AGENT_DISPATCH_DENIED", 403,
        "Only the exact selected actor credential generation may decline this dispatch");
    }
    const requestSha = await sha256Utf8(canonicalJson({
      protocol: "eliotr.computer-agent-dispatch-decline-request.v1",
      dispatch_id: dispatch.dispatch_id,
      connection_id: dispatch.connection_id,
      connection_revision: dispatch.connection_revision,
      actor: dispatch.actor,
      credential_generation: identity.credential_generation,
      idempotency_key: key,
      input: parsed.data,
    }));
    const replay = await readComputerAgentDispatchDeclineReplay(
      db, identity.issuer, identity.subject, key,
    );
    if (replay !== null) {
      if (replay.dispatch_id !== dispatch.dispatch_id ||
          replay.request_sha256 !== requestSha) {
        fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
          "Idempotency-Key is already bound to another dispatch decline");
      }
      serviceIdentity(context, now);
      return decodeComputerAgentDispatchDecline(replay);
    }
    const existing = await readComputerAgentDispatchDeclineRow(db, dispatch.dispatch_id);
    if (existing !== null) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Dispatch was already declined by another immutable action");
    }
    const [acceptance, abandonment] = await Promise.all([
      readComputerAgentDispatchAcceptanceRow(db, dispatch.dispatch_id),
      readComputerAgentDispatchAbandonmentRow(db, dispatch.dispatch_id),
    ]);
    if (acceptance !== null || abandonment !== null) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Accepted or abandoned dispatch cannot be declined");
    }
    const declinedAt = new Date(instant(now)).toISOString();
    const receipt = ComputerAgentDispatchDeclineReceiptSchema.parse({
      protocol: "eliotr.computer-agent-dispatch-declined.v1",
      dispatch_id: dispatch.dispatch_id,
      project_id: dispatch.project_id,
      connection_id: dispatch.connection_id,
      connection_revision: dispatch.connection_revision,
      actor: dispatch.actor,
      credential_generation: identity.credential_generation,
      reason: parsed.data.reason,
      ...(parsed.data.note === undefined ? {} : { note: parsed.data.note }),
      idempotency_key: key,
      request_sha256: requestSha,
      declined_at: declinedAt,
    });
    const record = canonicalJson(receipt);
    const digest = await sha256Utf8(record);
    serviceIdentity(context, now);
    try {
      await db.prepare("INSERT INTO computer_agent_dispatch_decline(" +
        "dispatch_id,project_id,connection_id,connection_revision,actor_issuer,actor_subject," +
        "credential_generation,reason,note,idempotency_key,request_sha256,record_json," +
        "record_sha256,declined_at) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14)")
        .bind(receipt.dispatch_id, receipt.project_id, receipt.connection_id,
          receipt.connection_revision, receipt.actor.issuer, receipt.actor.subject,
          receipt.credential_generation, receipt.reason, receipt.note ?? null,
          receipt.idempotency_key, receipt.request_sha256, record, digest,
          receipt.declined_at).run();
    } catch { /* Immutable readback below reconciles lost acknowledgements and races. */ }
    const settled = await readComputerAgentDispatchDeclineRow(db, dispatch.dispatch_id);
    if (settled === null) {
      fail("COMPUTER_AGENT_DISPATCH_SETTLEMENT_UNCERTAIN", 503,
        "Dispatch decline receipt is unavailable; retry with the same Idempotency-Key", true);
    }
    if (settled.request_sha256 !== requestSha || settled.idempotency_key !== key) {
      fail("COMPUTER_AGENT_DISPATCH_IDENTITY_CONFLICT", 409,
        "Dispatch settled another decline action");
    }
    const decoded = await decodeComputerAgentDispatchDecline(settled);
    if (canonicalJson(decoded) !== record) {
      fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
        "Dispatch decline readback differs from the intended record");
    }
    serviceIdentity(context, now);
    return decoded;
  }

  return { decline };
}
''')

write("apps/eliotr-core/src/computer-agent-dispatch-status.ts", r'''
import {
  ComputerAgentDispatchStatusSchema,
  type ComputerAgentDispatch,
  type ComputerAgentDispatchStatus,
} from "@eliotr/contracts";
import {
  decodeComputerAgentDispatchAbandonment,
  decodeComputerAgentDispatchAcceptance,
  decodeComputerAgentDispatchDecline,
  readComputerAgentDispatchAbandonmentRow,
  readComputerAgentDispatchAcceptanceRow,
  readComputerAgentDispatchDeclineRow,
  readCurrentComputerAgentDispatchOffer,
} from "./computer-agent-dispatch-record.js";
import { failComputerAgentDispatch as fail } from "./computer-agent-dispatch-error.js";

export async function readComputerAgentDispatchStatus(input: {
  readonly database: D1Database;
  readonly dispatch: ComputerAgentDispatch;
  readonly now: number;
}): Promise<ComputerAgentDispatchStatus> {
  const [acceptedRow, abandonedRow, declinedRow] = await Promise.all([
    readComputerAgentDispatchAcceptanceRow(input.database, input.dispatch.dispatch_id),
    readComputerAgentDispatchAbandonmentRow(input.database, input.dispatch.dispatch_id),
    readComputerAgentDispatchDeclineRow(input.database, input.dispatch.dispatch_id),
  ]);
  const acceptance = acceptedRow === null ? null
    : await decodeComputerAgentDispatchAcceptance(acceptedRow);
  const abandonment = abandonedRow === null ? null
    : await decodeComputerAgentDispatchAbandonment(abandonedRow);
  const decline = declinedRow === null ? null
    : await decodeComputerAgentDispatchDecline(declinedRow);
  const terminalCount = Number(acceptance !== null) +
    Number(abandonment !== null) + Number(decline !== null);
  if (terminalCount > 1) {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
      "Dispatch has conflicting terminal receipts");
  }
  const state = acceptance !== null ? "ACCEPTED" as const
    : abandonment !== null ? "ABANDONED" as const
      : decline !== null ? "DECLINED" as const
        : Date.parse(input.dispatch.expires_at) <= input.now ? "EXPIRED" as const
          : await readCurrentComputerAgentDispatchOffer(
              input.database, input.dispatch.dispatch_id,
            ) === null ? "STALE" as const : "PENDING" as const;
  return ComputerAgentDispatchStatusSchema.parse({
    protocol: "eliotr.computer-agent-dispatch-status.v1",
    state,
    dispatch: input.dispatch,
    acceptance,
    abandonment,
    decline,
  });
}
''')

replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '  ComputerAgentDispatchAbandonmentSchema,\n  ComputerAgentDispatchAcceptanceSchema,',
    '  ComputerAgentDispatchAbandonmentSchema,\n  ComputerAgentDispatchAcceptanceSchema,\n  ComputerAgentDispatchDeclineReceiptSchema,',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '  type ComputerAgentDispatchAbandonment,\n  type ComputerAgentDispatchAcceptance,',
    '  type ComputerAgentDispatchAbandonment,\n  type ComputerAgentDispatchAcceptance,\n  type ComputerAgentDispatchDeclineReceipt,',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export interface AbandonmentRow {
  dispatch_id: string;
  project_id: string;
  owner_principal_ref: string;
  owner_credential_generation: string;
  reason: string;
  note: string | null;
  idempotency_key: string;
  request_sha256: string;
  record_json: string;
  record_sha256: string;
  abandoned_at: string;
}
''',
    '''export interface AbandonmentRow {
  dispatch_id: string;
  project_id: string;
  owner_principal_ref: string;
  owner_credential_generation: string;
  reason: string;
  note: string | null;
  idempotency_key: string;
  request_sha256: string;
  record_json: string;
  record_sha256: string;
  abandoned_at: string;
}
export interface DeclineRow {
  dispatch_id: string;
  project_id: string;
  connection_id: string;
  connection_revision: number;
  actor_issuer: string;
  actor_subject: string;
  credential_generation: string;
  reason: string;
  note: string | null;
  idempotency_key: string;
  request_sha256: string;
  record_json: string;
  record_sha256: string;
  declined_at: string;
}
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export async function readComputerAgentDispatchRow(
''',
    '''export async function decodeComputerAgentDispatchDecline(
  row: DeclineRow,
): Promise<ComputerAgentDispatchDeclineReceipt> {
  let raw: unknown;
  try { raw = JSON.parse(row.record_json); }
  catch { return fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
    "Dispatch decline is not valid JSON"); }
  const parsed = ComputerAgentDispatchDeclineReceiptSchema.safeParse(raw);
  if (!parsed.success || canonicalJson(parsed.data) !== row.record_json ||
      await sha256Utf8(row.record_json) !== row.record_sha256 ||
      parsed.data.dispatch_id !== row.dispatch_id || parsed.data.project_id !== row.project_id ||
      parsed.data.connection_id !== row.connection_id ||
      parsed.data.connection_revision !== row.connection_revision ||
      parsed.data.actor.issuer !== row.actor_issuer ||
      parsed.data.actor.subject !== row.actor_subject ||
      parsed.data.credential_generation !== row.credential_generation ||
      parsed.data.reason !== row.reason || (parsed.data.note ?? null) !== row.note ||
      parsed.data.idempotency_key !== row.idempotency_key ||
      parsed.data.request_sha256 !== row.request_sha256 ||
      parsed.data.declined_at !== row.declined_at) {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
      "Dispatch decline identity is corrupt");
  }
  return parsed.data;
}

export async function readComputerAgentDispatchRow(
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '''export async function readCurrentComputerAgentDispatchOffer(
''',
    '''export async function readComputerAgentDispatchDeclineRow(
  db: D1Database,
  dispatchId: string,
): Promise<DeclineRow | null> {
  try {
    return await db.prepare(
      "SELECT * FROM computer_agent_dispatch_decline WHERE dispatch_id=?1 LIMIT 1",
    ).bind(dispatchId).first<DeclineRow>();
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Dispatch decline read is unavailable", true);
  }
}

export async function readComputerAgentDispatchDeclineReplay(
  db: D1Database,
  issuer: string,
  subject: string,
  key: string,
): Promise<DeclineRow | null> {
  try {
    return await db.prepare("SELECT * FROM computer_agent_dispatch_decline " +
      "WHERE actor_issuer=?1 AND actor_subject=?2 AND idempotency_key=?3 LIMIT 1")
      .bind(issuer, subject, key).first<DeclineRow>();
  } catch {
    fail("COMPUTER_AGENT_DISPATCH_STORAGE_UNAVAILABLE", 503,
      "Dispatch decline replay read is unavailable", true);
  }
}

export async function readCurrentComputerAgentDispatchOffer(
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-record.ts",
    '"SELECT * FROM computer_agent_dispatch_offer_actionable WHERE dispatch_id=?1 LIMIT 1"',
    '"SELECT * FROM computer_agent_dispatch_offer_claimable WHERE dispatch_id=?1 LIMIT 1"',
)

replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''  decodeComputerAgentDispatch,
  decodeComputerAgentDispatchAbandonment,
  decodeComputerAgentDispatchAcceptance,
  readComputerAgentDispatchAbandonmentRow,
  readComputerAgentDispatchAcceptanceRow,
''',
    '''  decodeComputerAgentDispatch,
  decodeComputerAgentDispatchAcceptance,
  readComputerAgentDispatchAcceptanceRow,
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''import type { Env } from "./env.js";

const SCHEMA_GENERATION = "computer-agent-dispatch-v1";
const ABANDONMENT_SCHEMA_GENERATION = "computer-agent-dispatch-abandonment-v1";
''',
    '''import { readComputerAgentDispatchStatus } from "./computer-agent-dispatch-status.js";
import type { Env } from "./env.js";

const SCHEMA_GENERATION = "computer-agent-dispatch-v1";
const ABANDONMENT_SCHEMA_GENERATION = "computer-agent-dispatch-abandonment-v1";
const DECLINE_SCHEMA_GENERATION = "computer-agent-dispatch-decline-v1";
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      "SELECT key,value FROM schema_state WHERE key IN (" +
      "'computer_agent_dispatch_generation','computer_agent_dispatch_abandonment_generation')",
''',
    '''      "SELECT key,value FROM schema_state WHERE key IN (" +
      "'computer_agent_dispatch_generation','computer_agent_dispatch_abandonment_generation'," +
      "'computer_agent_dispatch_decline_generation')",
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      "Computer-agent dispatch migrations 0090 and 0091 are required", true);
''',
    '''      "Computer-agent dispatch migrations 0090 through 0092 are required", true);
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      values.get("computer_agent_dispatch_abandonment_generation") !==
        ABANDONMENT_SCHEMA_GENERATION) {
''',
    '''      values.get("computer_agent_dispatch_abandonment_generation") !==
        ABANDONMENT_SCHEMA_GENERATION ||
      values.get("computer_agent_dispatch_decline_generation") !==
        DECLINE_SCHEMA_GENERATION) {
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '''      "Computer-agent dispatch migrations 0090 and 0091 are required", true);
''',
    '''      "Computer-agent dispatch migrations 0090 through 0092 are required", true);
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    r'''    const dispatch = await decodeComputerAgentDispatch(row);
    const [acceptedRow, abandonedRow] = await Promise.all([
      readComputerAgentDispatchAcceptanceRow(db, dispatchId),
      readComputerAgentDispatchAbandonmentRow(db, dispatchId),
    ]);
    const acceptance = acceptedRow === null ? null
      : await decodeComputerAgentDispatchAcceptance(acceptedRow);
    const abandonment = abandonedRow === null ? null
      : await decodeComputerAgentDispatchAbandonment(abandonedRow);
    if (acceptance !== null && abandonment !== null) {
      fail("COMPUTER_AGENT_DISPATCH_STORAGE_CORRUPT", 500,
        "Dispatch is both accepted and abandoned");
    }
    const state = acceptance !== null ? "ACCEPTED" as const
      : abandonment !== null ? "ABANDONED" as const
        : Date.parse(dispatch.expires_at) <= instant(now) ? "EXPIRED" as const
          : await readCurrentComputerAgentDispatchOffer(db, dispatchId) === null
            ? "STALE" as const : "PENDING" as const;
    owner(context, now);
    return ComputerAgentDispatchStatusSchema.parse({
      protocol: "eliotr.computer-agent-dispatch-status.v1",
      state, dispatch, acceptance, abandonment,
    });
''',
    r'''    const dispatch = await decodeComputerAgentDispatch(row);
    const result = await readComputerAgentDispatchStatus({
      database: db,
      dispatch,
      now: instant(now),
    });
    owner(context, now);
    return result;
''',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '"SELECT * FROM computer_agent_dispatch_offer_current " +',
    '"SELECT * FROM computer_agent_dispatch_offer_claimable " +',
)

replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-http.ts",
    'import { createComputerAgentDispatchAbandonmentService } from "./computer-agent-dispatch-abandonment.js";',
    'import { createComputerAgentDispatchAbandonmentService } from "./computer-agent-dispatch-abandonment.js";\nimport { createComputerAgentDispatchDeclineService } from "./computer-agent-dispatch-decline.js";',
)
replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-http.ts",
    '''    requireJson(request);
    const body: unknown = await readJsonBodyWithinBytes(request, maximumBytes);
''',
    '''    requireJson(request);
    const body: unknown = await readJsonBodyWithinBytes(request, maximumBytes);
    if (operation === "research.computer-agent-dispatches.decline") {
      return apiResult(request, env,
        await createComputerAgentDispatchDeclineService({ database: env.CORE_DB })
          .decline(context, params.dispatch_id ?? "", body));
    }
''',
)
replace_once(
    "apps/eliotr-core/src/http-special-routes.ts",
    '''    case "research.computer-agent-dispatches.accept":
      return handleComputerAgentDispatchHttp''',
    '''    case "research.computer-agent-dispatches.accept":
    case "research.computer-agent-dispatches.decline":
      return handleComputerAgentDispatchHttp''',
)
replace_once(
    "packages/interfaces/src/routes.ts",
    '''  { method: "POST", path: "/api/v1/research/computer-agent-dispatches/:dispatch_id/accept", operation: "research.computer-agent-dispatches.accept", auth: "service", maximum_request_bytes: 1024, response_mode: "json" },
''',
    '''  { method: "POST", path: "/api/v1/research/computer-agent-dispatches/:dispatch_id/accept", operation: "research.computer-agent-dispatches.accept", auth: "service", maximum_request_bytes: 1024, response_mode: "json" },
  { method: "POST", path: "/api/v1/research/computer-agent-dispatches/:dispatch_id/decline", operation: "research.computer-agent-dispatches.decline", auth: "service", maximum_request_bytes: 4096, response_mode: "json" },
''',
)

replace_once(
    "apps/eliotr-pwa/src/agent-inbox-dispatch.ts",
    '''const dispatchOutput = element("dispatch-output", HTMLPreElement);
''',
    '''const dispatchOutput = element("dispatch-output", HTMLPreElement);
const declineReason = element("decline-reason", HTMLSelectElement);
const declineNote = element("decline-note", HTMLInputElement);
const declineKey = element("decline-key", HTMLInputElement);
''',
)
replace_once(
    "apps/eliotr-pwa/src/agent-inbox-dispatch.ts",
    '''  dispatchIdInput.value = "";
  render(dispatchOutput, "No dispatch loaded.");
''',
    '''  dispatchIdInput.value = "";
  declineNote.value = "";
  declineKey.value = "";
  render(dispatchOutput, "No dispatch loaded.");
''',
)
replace_once(
    "apps/eliotr-pwa/src/agent-inbox-dispatch.ts",
    '''      dispatchIdInput.value = text(record(data.dispatch, "Dispatch").dispatch_id, "dispatch_id");
''',
    '''      dispatchIdInput.value = text(record(data.dispatch, "Dispatch").dispatch_id, "dispatch_id");
      if (declineKey.value.trim() === "") {
        declineKey.value = `agent-decline:${dispatchIdInput.value.slice(0, 64)}`;
      }
''',
)
replace_once(
    "apps/eliotr-pwa/src/agent-inbox-dispatch.ts",
    '''element("accept-dispatch", HTMLButtonElement).addEventListener("click", () => {
''',
    '''element("decline-dispatch", HTMLButtonElement).addEventListener("click", () => {
  void busy("Declining the owner-authorized dispatch…", async () => {
    const dispatchId = dispatchIdInput.value.trim();
    const key = declineKey.value.trim();
    const reason = declineReason.value;
    const note = declineNote.value.trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,255}$/u.test(dispatchId)) {
      throw new Error("Dispatch ID is invalid");
    }
    if (!/^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$/u.test(key)) {
      throw new Error("Decline idempotency key is invalid");
    }
    if (!["UNAVAILABLE", "UNSUPPORTED_TASK", "INSUFFICIENT_CONTEXT",
      "LOCAL_POLICY", "TRANSIENT_FAILURE", "OTHER"].includes(reason)) {
      throw new Error("Decline reason is invalid");
    }
    if (reason === "OTHER" && note === "") {
      throw new Error("OTHER decline requires a note");
    }
    const result = await decodedResponse(await sameOriginFetch(
      `/api/v1/research/computer-agent-dispatches/${encodeURIComponent(dispatchId)}/decline`,
      accessIdentity(),
      {
        method: "POST",
        idempotencyKey: key,
        body: JSON.stringify({ reason, ...(note === "" ? {} : { note }) }),
      },
    ));
    render(dispatchOutput, result);
    render(eventOutput, {
      message: "Dispatch declined. No workflow or task was transferred.",
      decline: apiData(result),
    });
  });
});

element("accept-dispatch", HTMLButtonElement).addEventListener("click", () => {
''',
)
replace_once(
    "apps/eliotr-pwa/src/pages/agent-inbox.astro",
    '''            <button id="accept-dispatch" class="button button--secondary" type="button" data-request>Accept dispatch</button>
''',
    '''            <button id="accept-dispatch" class="button button--secondary" type="button" data-request>Accept dispatch</button>
            <button id="decline-dispatch" class="button button--danger" type="button" data-request>Decline dispatch</button>
''',
)
replace_once(
    "apps/eliotr-pwa/src/pages/agent-inbox.astro",
    '''        <label>
          <span>Dispatch ID</span>
          <input id="dispatch-id" type="text" autocomplete="off" spellcheck="false" />
        </label>
''',
    '''        <div class="form-grid">
          <label>
            <span>Dispatch ID</span>
            <input id="dispatch-id" type="text" autocomplete="off" spellcheck="false" />
          </label>
          <label>
            <span>Decline reason</span>
            <select id="decline-reason">
              <option value="UNAVAILABLE">Unavailable</option>
              <option value="UNSUPPORTED_TASK">Unsupported task</option>
              <option value="INSUFFICIENT_CONTEXT">Insufficient context</option>
              <option value="LOCAL_POLICY">Local policy</option>
              <option value="TRANSIENT_FAILURE">Transient failure</option>
              <option value="OTHER">Other</option>
            </select>
          </label>
          <label>
            <span>Decline idempotency key</span>
            <input id="decline-key" type="text" autocomplete="off" spellcheck="false" />
          </label>
          <label>
            <span>Optional decline note</span>
            <input id="decline-note" type="text" maxlength="2048" autocomplete="off" spellcheck="false" />
          </label>
        </div>
''',
)


replace_once(
    "apps/eliotr-core/src/computer-agent-dispatch-store.ts",
    '  ComputerAgentDispatchSchema,\n  ComputerAgentDispatchStatusSchema,\n',
    '  ComputerAgentDispatchSchema,\n',
)

append_once(
    "docs/adr/0007-external-agents-and-cloudflare-evolution.md",
    "### Explicit target decline",
    r'''
### Explicit target decline

An exact selected Spark, Muse, Dot, or other service actor may decline an unaccepted dispatch under the
credential generation recorded by the owner. Decline is immutable delivery state, not failover: the old
offer disappears, no Research run starts, and no task or lease moves. The owner must observe readiness
again and issue a distinct dispatch to any replacement contour. Owner abandonment and target decline are
mutually exclusive with acceptance.
''',
)
append_once(
    "docs/adr/0008-computer-agent-web-inbox.md",
    "## Target decline",
    r'''
## Target decline

The web inbox exposes the same exact service-actor decline as the MCP/API contour. A decline never selects
the next route entry or inherits another credential's authority. The owner may create a replacement only
after reading current readiness and using a new dispatch identity.
''',
)
append_once(
    "docs/implementation/computer-agent-web-inbox.md",
    "### Declining an offer",
    r'''
### Declining an offer

Before acceptance, the exact selected credential generation may submit one stable decline key and reason.
Retry the same key and body after an uncertain response. `DECLINED` means no workflow was created. The
owner must create another dispatch explicitly; an accepted run instead uses normal cancel/recover controls.
''',
)
append_once(
    "docs/implementation/muse-operator-runbook.md",
    "### Decline without transfer",
    r'''
### Decline without transfer

When the selected contour cannot execute an offered dispatch, use the exact decline operation rather than
accepting and abandoning work later. A decline closes only that offer. It does not move the task, grant,
lease, browser session, or credential authority to another contour.
''',
)
